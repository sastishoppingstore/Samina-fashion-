using ECommerceApp.Models.ViewModels;
using ECommerceApp.Services;
using Microsoft.AspNetCore.Mvc;

namespace ECommerceApp.Controllers
{
    public class CartController : Controller
    {
        private readonly IShoppingCartService _cartService;
        private readonly IProductService _productService;

        public CartController(IShoppingCartService cartService, IProductService productService)
        {
            _cartService = cartService;
            _productService = productService;
        }

        public async Task<IActionResult> Index()
        {
            var sessionId = GetSessionId();
            var cart = await _cartService.GetCartViewModelAsync(sessionId);
            return View(cart);
        }

        [HttpPost]
        public async Task<IActionResult> AddToCart(int productId, int quantity = 1)
        {
            try
            {
                var sessionId = GetSessionId();
                await _cartService.AddToCartAsync(sessionId, productId, quantity);
                
                var cartCount = await _cartService.GetCartItemCountAsync(sessionId);
                
                return Json(new { success = true, message = "Product added to cart", cartCount });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> RemoveFromCart(int productId)
        {
            try
            {
                var sessionId = GetSessionId();
                await _cartService.RemoveFromCartAsync(sessionId, productId);
                
                var cart = await _cartService.GetCartViewModelAsync(sessionId);
                
                return Json(new { 
                    success = true, 
                    message = "Product removed from cart",
                    cartCount = cart.TotalItems,
                    subTotal = cart.SubTotal.ToString("C"),
                    total = cart.Total.ToString("C")
                });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> UpdateQuantity(int productId, int quantity)
        {
            try
            {
                var sessionId = GetSessionId();
                await _cartService.UpdateQuantityAsync(sessionId, productId, quantity);
                
                var cart = await _cartService.GetCartViewModelAsync(sessionId);
                var item = cart.Items.FirstOrDefault(i => i.ProductId == productId);
                
                return Json(new { 
                    success = true, 
                    message = "Quantity updated",
                    cartCount = cart.TotalItems,
                    itemTotal = item?.TotalPrice.ToString("C"),
                    subTotal = cart.SubTotal.ToString("C"),
                    total = cart.Total.ToString("C")
                });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> ClearCart()
        {
            try
            {
                var sessionId = GetSessionId();
                await _cartService.ClearCartAsync(sessionId);
                
                return Json(new { success = true, message = "Cart cleared", cartCount = 0 });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetCartCount()
        {
            var sessionId = GetSessionId();
            var count = await _cartService.GetCartItemCountAsync(sessionId);
            return Json(new { count });
        }

        private string GetSessionId()
        {
            var sessionId = HttpContext.Session.GetString("CartSessionId");
            if (string.IsNullOrEmpty(sessionId))
            {
                sessionId = Guid.NewGuid().ToString();
                HttpContext.Session.SetString("CartSessionId", sessionId);
            }
            return sessionId;
        }
    }
}
