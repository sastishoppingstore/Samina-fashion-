using ECommerceApp.Models;
using ECommerceApp.Models.ViewModels;
using ECommerceApp.Services;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace ECommerceApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ICategoryService _categoryService;
        private readonly IProductService _productService;
        private readonly ISeoService _seoService;
        private readonly ILogger<HomeController> _logger;

        public HomeController(
            ICategoryService categoryService,
            IProductService productService,
            ISeoService seoService,
            ILogger<HomeController> logger)
        {
            _categoryService = categoryService;
            _productService = productService;
            _seoService = seoService;
            _logger = logger;
        }

        public async Task<IActionResult> Index()
        {
            var categorySections = await _categoryService.GetHomepageCategorySectionsAsync();
            var featuredProducts = await _productService.GetFeaturedProductsAsync(8);

            var viewModel = new HomepageViewModel
            {
                CategorySections = categorySections.ToList(),
                FeaturedProducts = featuredProducts.ToList()
            };

            // SEO Data
            var seoData = _seoService.GetHomepageSeoData();
            ViewBag.SeoData = seoData;
            ViewBag.StructuredData = _seoService.GenerateStructuredDataOrganization();

            return View(viewModel);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Terms()
        {
            return View();
        }

        public IActionResult Contact()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }

        [Route("sitemap.xml")]
        public async Task<IActionResult> Sitemap()
        {
            var siteUrl = "https://yourdomain.com";
            var categories = await _categoryService.GetActiveCategoriesAsync();
            var products = await _productService.GetActiveProductsAsync();

            var sitemap = $"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
            sitemap += $"<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n";
            
            // Homepage
            sitemap += $"  <url>\n    <loc>{siteUrl}</loc>\n    <changefreq>daily</changefreq>\n    <priority>1.0</priority>\n  </url>\n";
            
            // Categories
            foreach (var category in categories)
            {
                sitemap += $"  <url>\n    <loc>{siteUrl}/category/{category.Slug}</loc>\n    <changefreq>weekly</changefreq>\n    <priority>0.8</priority>\n  </url>\n";
            }
            
            // Products
            foreach (var product in products)
            {
                sitemap += $"  <url>\n    <loc>{siteUrl}/product/{product.Slug}</loc>\n    <changefreq>weekly</changefreq>\n    <priority>0.6</priority>\n  </url>\n";
            }
            
            sitemap += "</urlset>";

            return Content(sitemap, "application/xml");
        }

        [Route("robots.txt")]
        public IActionResult Robots()
        {
            var siteUrl = "https://yourdomain.com";
            var robots = $"User-agent: *\n";
            robots += $"Allow: /\n";
            robots += $"Disallow: /admin/\n";
            robots += $"Disallow: /account/\n";
            robots += $"Disallow: /cart/\n";
            robots += $"Disallow: /checkout/\n";
            robots += $"Sitemap: {siteUrl}/sitemap.xml\n";

            return Content(robots, "text/plain");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
