using ECommerceApp.Models;
using ECommerceApp.Models.ViewModels;
using ECommerceApp.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ECommerceApp.Controllers
{
    public class CheckoutController : Controller
    {
        private readonly IShoppingCartService _cartService;
        private readonly IOrderService _orderService;
        private readonly IProductService _productService;

        public CheckoutController(
            IShoppingCartService cartService,
            IOrderService orderService,
            IProductService productService)
        {
            _cartService = cartService;
            _orderService = orderService;
            _productService = productService;
        }

        public async Task<IActionResult> Index()
        {
            var sessionId = GetSessionId();
            var cart = await _cartService.GetCartViewModelAsync(sessionId);

            if (cart.Items.Count == 0)
            {
                TempData["Error"] = "Your cart is empty.";
                return RedirectToAction("Index", "Cart");
            }

            var model = new CheckoutViewModel
            {
                Cart = new ShoppingCart(),
                ShippingCost = cart.SubTotal >= 50 ? 0 : 5.99m,
                TaxRate = 8.0m
            };

            ViewBag.Cart = cart;

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(CheckoutViewModel model)
        {
            var sessionId = GetSessionId();
            var cart = await _cartService.GetCartAsync(sessionId);

            if (cart.Items.Count == 0)
            {
                TempData["Error"] = "Your cart is empty.";
                return RedirectToAction("Index", "Cart");
            }

            if (!ModelState.IsValid)
            {
                ViewBag.Cart = await _cartService.GetCartViewModelAsync(sessionId);
                return View(model);
            }

            try
            {
                var confirmation = await _orderService.CreateOrderAsync(model, cart);
                await _cartService.ClearCartAsync(sessionId);

                return RedirectToAction("Confirmation", new { orderNumber = confirmation.OrderNumber });
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                ViewBag.Cart = await _cartService.GetCartViewModelAsync(sessionId);
                return View(model);
            }
        }

        public async Task<IActionResult> Confirmation(string orderNumber)
        {
            if (string.IsNullOrEmpty(orderNumber))
            {
                return RedirectToAction("Index", "Home");
            }

            var order = await _orderService.GetOrderByNumberAsync(orderNumber);
            if (order == null)
            {
                return NotFound();
            }

            var viewModel = new OrderConfirmationViewModel
            {
                OrderNumber = order.OrderNumber,
                TotalAmount = order.TotalAmount,
                CustomerEmail = order.CustomerEmail,
                CreatedAt = order.CreatedAt
            };

            return View(viewModel);
        }

        [HttpPost]
        public async Task<IActionResult> OrderNow(int productId, int quantity = 1)
        {
            try
            {
                var sessionId = GetSessionId();
                
                // Clear cart and add only this product
                await _cartService.ClearCartAsync(sessionId);
                await _cartService.AddToCartAsync(sessionId, productId, quantity);
                
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["Error"] = ex.Message;
                return RedirectToAction("Details", "Product", new { id = productId });
            }
        }

        private string GetSessionId()
        {
            var sessionId = HttpContext.Session.GetString("CartSessionId");
            if (string.IsNullOrEmpty(sessionId))
            {
                sessionId = Guid.NewGuid().ToString();
                HttpContext.Session.SetString("CartSessionId", sessionId);
            }
            return sessionId;
        }
    }
}
