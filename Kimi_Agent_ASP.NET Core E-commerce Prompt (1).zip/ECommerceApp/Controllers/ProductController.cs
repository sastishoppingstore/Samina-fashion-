using ECommerceApp.Models.ViewModels;
using ECommerceApp.Services;
using Microsoft.AspNetCore.Mvc;

namespace ECommerceApp.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductService _productService;
        private readonly ISeoService _seoService;

        public ProductController(IProductService productService, ISeoService seoService)
        {
            _productService = productService;
            _seoService = seoService;
        }

        [Route("product/{slug}")]
        public async Task<IActionResult> Details(string slug)
        {
            if (string.IsNullOrEmpty(slug))
            {
                return NotFound();
            }

            var product = await _productService.GetProductBySlugAsync(slug);
            if (product == null)
            {
                return NotFound();
            }

            // SEO Data
            var seoData = _seoService.GetProductSeoData(product);
            ViewBag.SeoData = seoData;
            ViewBag.StructuredData = _seoService.GenerateStructuredDataProduct(product);
            ViewBag.BreadcrumbData = _seoService.GenerateBreadcrumbJsonLd(new List<BreadcrumbItem>
            {
                new BreadcrumbItem { Name = "Home", Url = "/" },
                new BreadcrumbItem { Name = product.CategoryName, Url = $"/category/{product.CategorySlug}" },
                new BreadcrumbItem { Name = product.Name, Url = null }
            });

            return View(product);
        }

        public async Task<IActionResult> Search(string q, int page = 1)
        {
            if (string.IsNullOrWhiteSpace(q))
            {
                return View(new SearchResultViewModel { Query = q ?? string.Empty });
            }

            var products = await _productService.SearchProductsAsync(q);
            
            var viewModel = new SearchResultViewModel
            {
                Query = q,
                Products = products.ToList(),
                TotalResults = products.Count(),
                CurrentPage = page,
                TotalPages = (int)Math.Ceiling(products.Count() / 12.0)
            };

            ViewBag.SeoData = new SeoMetaData
            {
                Title = $"Search Results for '{q}'",
                Description = $"Find products matching '{q}'. Browse our selection and shop online.",
                CanonicalUrl = $"/product/search?q={Uri.EscapeDataString(q)}"
            };

            return View(viewModel);
        }

        public async Task<IActionResult> Featured()
        {
            var products = await _productService.GetFeaturedProductsAsync(24);
            
            ViewBag.SeoData = new SeoMetaData
            {
                Title = "Featured Products",
                Description = "Discover our featured products - handpicked selection of the best items.",
                CanonicalUrl = "/product/featured"
            };

            return View(products);
        }

        public async Task<IActionResult> Latest()
        {
            var products = await _productService.GetLatestProductsAsync(24);
            
            ViewBag.SeoData = new SeoMetaData
            {
                Title = "New Arrivals",
                Description = "Check out our latest products - fresh arrivals just for you.",
                CanonicalUrl = "/product/latest"
            };

            return View(products);
        }
    }
}
