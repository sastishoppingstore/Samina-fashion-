using ECommerceApp.Models.ViewModels;
using ECommerceApp.Services;
using Microsoft.AspNetCore.Mvc;

namespace ECommerceApp.Controllers
{
    public class CategoryController : Controller
    {
        private readonly ICategoryService _categoryService;
        private readonly ISeoService _seoService;

        public CategoryController(ICategoryService categoryService, ISeoService seoService)
        {
            _categoryService = categoryService;
            _seoService = seoService;
        }

        [Route("category/{slug}")]
        public async Task<IActionResult> Products(string slug, int page = 1)
        {
            if (string.IsNullOrEmpty(slug))
            {
                return NotFound();
            }

            var category = await _categoryService.GetCategoryWithProductsAsync(slug);
            if (category == null)
            {
                return NotFound();
            }

            // SEO Data
            var seoData = _seoService.GetCategorySeoData(category);
            ViewBag.SeoData = seoData;
            ViewBag.BreadcrumbData = _seoService.GenerateBreadcrumbJsonLd(new List<BreadcrumbItem>
            {
                new BreadcrumbItem { Name = "Home", Url = "/" },
                new BreadcrumbItem { Name = category.Name, Url = null }
            });

            return View(category);
        }

        public async Task<IActionResult> Index()
        {
            var categories = await _categoryService.GetActiveCategoriesAsync();
            
            ViewBag.SeoData = new SeoMetaData
            {
                Title = "All Categories",
                Description = "Browse all product categories in our store.",
                CanonicalUrl = "/category"
            };

            return View(categories);
        }
    }
}
