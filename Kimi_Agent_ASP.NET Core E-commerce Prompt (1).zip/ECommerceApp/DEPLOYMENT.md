# E-Commerce Application - Deployment Guide

## 🚀 READY FOR PUBLISH – SmarterASP.NET Optimized

---

## Prerequisites

1. **.NET 8.0 SDK** installed on your development machine
2. **SQL Server** database (local or remote)
3. **Visual Studio 2022** or **VS Code**
4. **SmarterASP.NET Hosting Account** (or any IIS hosting)

---

## Local Development Setup

### Step 1: Clone/Extract the Project

```bash
cd ECommerceApp
```

### Step 2: Update Connection String

Edit `appsettings.Development.json`:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=ECommerceDB_Dev;Trusted_Connection=True;TrustServerCertificate=True;"
  }
}
```

### Step 3: Run Database Migrations

```bash
dotnet ef migrations add InitialCreate
dotnet ef database update
```

Or use the SQL script:

```bash
sqlcmd -S (localdb)\mssqllocaldb -i Database.sql
```

### Step 4: Run the Application

```bash
dotnet run
```

Navigate to: `https://localhost:5001`

**Default Admin Credentials:**
- Email: `admin@ecommerce.com`
- Password: `Admin@123456`

---

## Production Deployment (SmarterASP.NET)

### Step 1: Update Production Settings

Edit `appsettings.json`:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=YOUR_SQL_SERVER;Database=ECommerceDB;User Id=YOUR_USERNAME;Password=YOUR_PASSWORD;TrustServerCertificate=True;MultipleActiveResultSets=true;"
  },
  "AppSettings": {
    "SiteName": "Your Store Name",
    "SiteUrl": "https://yourdomain.com"
  }
}
```

### Step 2: Publish the Application

#### Option A: Visual Studio Publish

1. Right-click on project → **Publish**
2. Select **Folder** as target
3. Configure settings:
   - Configuration: **Release**
   - Target Framework: **net8.0**
   - Deployment Mode: **Self-contained** (recommended for SmarterASP.NET)
   - Target Runtime: **win-x86**
4. Click **Publish**

#### Option B: Command Line

```bash
dotnet publish -c Release -r win-x86 --self-contained true -o ./publish
```

### Step 3: Upload to SmarterASP.NET

1. **Login** to your SmarterASP.NET control panel
2. Go to **File Manager** or use **FTP**
3. Upload published files to the `wwwroot` folder
4. Ensure `web.config` is in the root directory

### Step 4: Configure Database

1. Create database in SmarterASP.NET control panel
2. Run `Database.sql` script to create tables
3. Update connection string in `appsettings.json`

### Step 5: Configure IIS Settings

The `web.config` file is already configured with:
- ✅ Response Compression (Gzip)
- ✅ Static Content Caching
- ✅ HTTPS Redirection
- ✅ Security Headers
- ✅ URL Rewrite Rules

---

## Folder Structure

```
ECommerceApp/
├── Areas/
│   └── Admin/
│       ├── Controllers/
│       └── Views/
├── Controllers/
├── Data/
├── Models/
├── Repositories/
├── Services/
├── Views/
├── wwwroot/
│   ├── css/
│   ├── js/
│   ├── uploads/
│   └── images/
├── appsettings.json
├── appsettings.Development.json
├── web.config
├── Database.sql
└── ECommerceApp.csproj
```

---

## Performance Optimization (Already Implemented)

### ✅ Database Optimization
- Proper indexing on all tables
- AsNoTracking for read-only queries
- Query optimization with includes

### ✅ Caching
- Response Compression (Gzip/Brotli)
- Output Caching for static content
- Static file client-side caching (1 year)

### ✅ Image Optimization
- WebP format conversion
- Automatic resizing (max 1200px)
- Lazy loading for images

### ✅ Code Optimization
- Repository Pattern
- Async/Await throughout
- Minimal jQuery usage

---

## Security Features

### ✅ Implemented
- HTTPS enforcement
- Security headers (HSTS, X-Frame-Options, etc.)
- Anti-forgery tokens
- Input validation
- SQL injection prevention (EF Core)
- XSS protection
- File upload validation

---

## SEO Features

### ✅ Implemented
- Dynamic meta tags
- Open Graph tags
- Structured data (JSON-LD)
- Sitemap.xml generation
- Robots.txt
- Clean URLs with slugs
- Canonical URLs
- Breadcrumb navigation

---

## Troubleshooting

### Issue: 500 Internal Server Error

**Solution:**
1. Check `web.config` is properly formatted
2. Verify .NET 8.0 Hosting Bundle is installed on server
3. Check file permissions (755 for folders, 644 for files)
4. Review application logs

### Issue: Database Connection Failed

**Solution:**
1. Verify connection string
2. Ensure SQL Server allows remote connections
3. Check firewall settings
4. Verify database user permissions

### Issue: Images Not Loading

**Solution:**
1. Create `wwwroot/uploads/products` and `wwwroot/uploads/categories` folders
2. Set folder permissions to 755
3. Verify image file extensions are allowed

### Issue: Session Not Working

**Solution:**
1. Ensure session state is configured in `web.config`
2. Check cookie settings in browser
3. Verify session timeout settings

---

## Post-Deployment Checklist

- [ ] Update `appsettings.json` with production values
- [ ] Change default admin password
- [ ] Configure email settings (if needed)
- [ ] Set up SSL certificate
- [ ] Configure backup schedule
- [ ] Test all major functionality
- [ ] Verify mobile responsiveness
- [ ] Check page load speed
- [ ] Submit sitemap to Google

---

## Support

For issues or questions:
1. Check the logs in `/logs` folder
2. Review SmarterASP.NET knowledge base
3. Contact your hosting provider

---

**READY FOR PUBLISH – SmarterASP.NET Optimized**
