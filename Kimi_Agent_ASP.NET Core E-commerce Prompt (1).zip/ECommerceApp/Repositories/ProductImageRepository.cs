using ECommerceApp.Data;
using ECommerceApp.Models;
using Microsoft.EntityFrameworkCore;

namespace ECommerceApp.Repositories
{
    public class ProductImageRepository : Repository<ProductImage>, IProductImageRepository
    {
        public ProductImageRepository(ApplicationDbContext context) : base(context)
        {
        }

        public async Task<IEnumerable<ProductImage>> GetByProductIdAsync(int productId)
        {
            return await _dbSet
                .AsNoTracking()
                .Where(pi => pi.ProductId == productId)
                .OrderBy(pi => pi.DisplayOrder)
                .ToListAsync();
        }

        public async Task<ProductImage?> GetPrimaryImageAsync(int productId)
        {
            return await _dbSet
                .AsNoTracking()
                .FirstOrDefaultAsync(pi => pi.ProductId == productId && pi.IsPrimary);
        }

        public async Task SetPrimaryImageAsync(int productId, int imageId)
        {
            var existingPrimary = await _dbSet
                .FirstOrDefaultAsync(pi => pi.ProductId == productId && pi.IsPrimary);

            if (existingPrimary != null)
            {
                existingPrimary.IsPrimary = false;
            }

            var newPrimary = await _dbSet.FindAsync(imageId);
            if (newPrimary != null && newPrimary.ProductId == productId)
            {
                newPrimary.IsPrimary = true;
            }

            await _context.SaveChangesAsync();
        }
    }
}
