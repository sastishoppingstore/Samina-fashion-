using ECommerceApp.Data;
using ECommerceApp.Models;
using Microsoft.EntityFrameworkCore;

namespace ECommerceApp.Repositories
{
    public class OrderRepository : Repository<Order>, IOrderRepository
    {
        public OrderRepository(ApplicationDbContext context) : base(context)
        {
        }

        public async Task<Order?> GetByOrderNumberAsync(string orderNumber)
        {
            return await _dbSet
                .AsNoTracking()
                .FirstOrDefaultAsync(o => o.OrderNumber == orderNumber);
        }

        public async Task<Order?> GetByOrderNumberWithDetailsAsync(string orderNumber)
        {
            return await _dbSet
                .AsNoTracking()
                .Include(o => o.OrderItems)
                .ThenInclude(oi => oi.Product)
                .FirstOrDefaultAsync(o => o.OrderNumber == orderNumber);
        }

        public async Task<IEnumerable<Order>> GetByUserIdAsync(string userId)
        {
            return await _dbSet
                .AsNoTracking()
                .Where(o => o.UserId == userId)
                .Include(o => o.OrderItems)
                .OrderByDescending(o => o.CreatedAt)
                .ToListAsync();
        }

        public async Task<IEnumerable<Order>> GetByStatusAsync(OrderStatus status)
        {
            return await _dbSet
                .AsNoTracking()
                .Where(o => o.OrderStatus == status)
                .Include(o => o.OrderItems)
                .OrderByDescending(o => o.CreatedAt)
                .ToListAsync();
        }

        public async Task<IEnumerable<Order>> GetRecentOrdersAsync(int count)
        {
            return await _dbSet
                .AsNoTracking()
                .Include(o => o.OrderItems)
                .OrderByDescending(o => o.CreatedAt)
                .Take(count)
                .ToListAsync();
        }

        public async Task<decimal> GetTotalRevenueAsync()
        {
            return await _dbSet
                .AsNoTracking()
                .Where(o => o.OrderStatus != OrderStatus.Cancelled && o.PaymentStatus == PaymentStatus.Paid)
                .SumAsync(o => o.TotalAmount);
        }

        public async Task<decimal> GetTodayRevenueAsync()
        {
            var today = DateTime.UtcNow.Date;
            return await _dbSet
                .AsNoTracking()
                .Where(o => o.OrderStatus != OrderStatus.Cancelled && 
                            o.PaymentStatus == PaymentStatus.Paid &&
                            o.CreatedAt.Date == today)
                .SumAsync(o => o.TotalAmount);
        }

        public async Task<decimal> GetMonthRevenueAsync()
        {
            var firstDayOfMonth = new DateTime(DateTime.UtcNow.Year, DateTime.UtcNow.Month, 1);
            return await _dbSet
                .AsNoTracking()
                .Where(o => o.OrderStatus != OrderStatus.Cancelled && 
                            o.PaymentStatus == PaymentStatus.Paid &&
                            o.CreatedAt >= firstDayOfMonth)
                .SumAsync(o => o.TotalAmount);
        }

        public async Task<int> GetTotalOrdersCountAsync()
        {
            return await _dbSet.CountAsync();
        }

        public async Task<int> GetOrdersCountByStatusAsync(OrderStatus status)
        {
            return await _dbSet.CountAsync(o => o.OrderStatus == status);
        }

        public async Task<(IEnumerable<Order> Orders, int TotalCount)> GetPagedOrdersAsync(
            int page, 
            int pageSize, 
            OrderStatus? status = null, 
            DateTime? fromDate = null, 
            DateTime? toDate = null, 
            string? searchTerm = null)
        {
            var query = _dbSet.AsNoTracking();

            if (status.HasValue)
                query = query.Where(o => o.OrderStatus == status.Value);

            if (fromDate.HasValue)
                query = query.Where(o => o.CreatedAt >= fromDate.Value);

            if (toDate.HasValue)
                query = query.Where(o => o.CreatedAt <= toDate.Value.AddDays(1).AddTicks(-1));

            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                searchTerm = searchTerm.ToLower();
                query = query.Where(o => 
                    o.OrderNumber.ToLower().Contains(searchTerm) ||
                    o.CustomerName.ToLower().Contains(searchTerm) ||
                    o.CustomerEmail.ToLower().Contains(searchTerm));
            }

            var totalCount = await query.CountAsync();

            var orders = await query
                .Include(o => o.OrderItems)
                .OrderByDescending(o => o.CreatedAt)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return (orders, totalCount);
        }
    }
}
