using ECommerceApp.Models;

namespace ECommerceApp.Repositories
{
    public interface ICategoryRepository : IRepository<Category>
    {
        Task<Category?> GetBySlugAsync(string slug);
        Task<Category?> GetBySlugWithProductsAsync(string slug);
        Task<IEnumerable<Category>> GetActiveCategoriesAsync();
        Task<IEnumerable<Category>> GetActiveCategoriesWithProductsAsync(int maxProductsPerCategory);
        Task<IEnumerable<Category>> GetParentCategoriesAsync();
        Task<bool> SlugExistsAsync(string slug, int? excludeId = null);
        Task<int> GetProductCountAsync(int categoryId);
    }
}
