using ECommerceApp.Models;

namespace ECommerceApp.Repositories
{
    public interface IOrderRepository : IRepository<Order>
    {
        Task<Order?> GetByOrderNumberAsync(string orderNumber);
        Task<Order?> GetByOrderNumberWithDetailsAsync(string orderNumber);
        Task<IEnumerable<Order>> GetByUserIdAsync(string userId);
        Task<IEnumerable<Order>> GetByStatusAsync(OrderStatus status);
        Task<IEnumerable<Order>> GetRecentOrdersAsync(int count);
        Task<decimal> GetTotalRevenueAsync();
        Task<decimal> GetTodayRevenueAsync();
        Task<decimal> GetMonthRevenueAsync();
        Task<int> GetTotalOrdersCountAsync();
        Task<int> GetOrdersCountByStatusAsync(OrderStatus status);
        Task<(IEnumerable<Order> Orders, int TotalCount)> GetPagedOrdersAsync(
            int page, 
            int pageSize, 
            OrderStatus? status = null, 
            DateTime? fromDate = null, 
            DateTime? toDate = null, 
            string? searchTerm = null);
    }
}
