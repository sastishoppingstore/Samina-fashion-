using ECommerceApp.Data;
using ECommerceApp.Models;
using Microsoft.EntityFrameworkCore;

namespace ECommerceApp.Repositories
{
    public class ProductRepository : Repository<Product>, IProductRepository
    {
        public ProductRepository(ApplicationDbContext context) : base(context)
        {
        }

        public async Task<Product?> GetBySlugAsync(string slug)
        {
            return await _dbSet
                .AsNoTracking()
                .FirstOrDefaultAsync(p => p.Slug == slug && p.IsActive);
        }

        public async Task<Product?> GetBySlugWithDetailsAsync(string slug)
        {
            return await _dbSet
                .AsNoTracking()
                .Include(p => p.Images)
                .Include(p => p.Category)
                .FirstOrDefaultAsync(p => p.Slug == slug && p.IsActive);
        }

        public async Task<IEnumerable<Product>> GetActiveProductsAsync()
        {
            return await _dbSet
                .AsNoTracking()
                .Where(p => p.IsActive)
                .Include(p => p.Images)
                .Include(p => p.Category)
                .OrderByDescending(p => p.CreatedAt)
                .ToListAsync();
        }

        public async Task<IEnumerable<Product>> GetProductsByCategoryAsync(int categoryId)
        {
            return await _dbSet
                .AsNoTracking()
                .Where(p => p.CategoryId == categoryId && p.IsActive)
                .Include(p => p.Images)
                .OrderByDescending(p => p.CreatedAt)
                .ToListAsync();
        }

        public async Task<IEnumerable<Product>> GetFeaturedProductsAsync(int count)
        {
            return await _dbSet
                .AsNoTracking()
                .Where(p => p.IsActive && p.IsFeatured)
                .Include(p => p.Images)
                .Include(p => p.Category)
                .OrderByDescending(p => p.CreatedAt)
                .Take(count)
                .ToListAsync();
        }

        public async Task<IEnumerable<Product>> GetLatestProductsAsync(int count)
        {
            return await _dbSet
                .AsNoTracking()
                .Where(p => p.IsActive)
                .Include(p => p.Images)
                .Include(p => p.Category)
                .OrderByDescending(p => p.CreatedAt)
                .Take(count)
                .ToListAsync();
        }

        public async Task<IEnumerable<Product>> SearchProductsAsync(string searchTerm)
        {
            if (string.IsNullOrWhiteSpace(searchTerm))
                return new List<Product>();

            searchTerm = searchTerm.ToLower();
            
            return await _dbSet
                .AsNoTracking()
                .Where(p => p.IsActive && (
                    p.Name.ToLower().Contains(searchTerm) ||
                    p.ShortDescription.ToLower().Contains(searchTerm) ||
                    p.FullDescription.ToLower().Contains(searchTerm) ||
                    p.Keywords != null && p.Keywords.ToLower().Contains(searchTerm)))
                .Include(p => p.Images)
                .Include(p => p.Category)
                .OrderByDescending(p => p.CreatedAt)
                .ToListAsync();
        }

        public async Task<IEnumerable<Product>> GetLowStockProductsAsync()
        {
            return await _dbSet
                .AsNoTracking()
                .Where(p => p.StockQuantity <= p.StockThreshold && p.StockQuantity > 0 && p.IsActive)
                .Include(p => p.Images)
                .Include(p => p.Category)
                .ToListAsync();
        }

        public async Task<IEnumerable<Product>> GetOutOfStockProductsAsync()
        {
            return await _dbSet
                .AsNoTracking()
                .Where(p => p.StockQuantity <= 0 && p.IsActive)
                .Include(p => p.Images)
                .Include(p => p.Category)
                .ToListAsync();
        }

        public async Task<bool> SlugExistsAsync(string slug, int? excludeId = null)
        {
            if (excludeId.HasValue)
            {
                return await _dbSet.AnyAsync(p => p.Slug == slug && p.Id != excludeId.Value);
            }
            return await _dbSet.AnyAsync(p => p.Slug == slug);
        }

        public async Task IncrementViewCountAsync(int productId)
        {
            var product = await _dbSet.FindAsync(productId);
            if (product != null)
            {
                product.ViewCount++;
                await _context.SaveChangesAsync();
            }
        }

        public async Task<(IEnumerable<Product> Products, int TotalCount)> GetPagedProductsAsync(
            int page, 
            int pageSize, 
            int? categoryId = null, 
            string? searchTerm = null, 
            bool? isActive = null,
            bool? isFeatured = null)
        {
            var query = _dbSet.AsNoTracking();

            if (categoryId.HasValue)
                query = query.Where(p => p.CategoryId == categoryId.Value);

            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                searchTerm = searchTerm.ToLower();
                query = query.Where(p => 
                    p.Name.ToLower().Contains(searchTerm) ||
                    p.ShortDescription.ToLower().Contains(searchTerm));
            }

            if (isActive.HasValue)
                query = query.Where(p => p.IsActive == isActive.Value);

            if (isFeatured.HasValue)
                query = query.Where(p => p.IsFeatured == isFeatured.Value);

            var totalCount = await query.CountAsync();

            var products = await query
                .Include(p => p.Images)
                .Include(p => p.Category)
                .OrderByDescending(p => p.CreatedAt)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return (products, totalCount);
        }
    }
}
