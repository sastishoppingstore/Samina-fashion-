using ECommerceApp.Data;
using ECommerceApp.Models;
using Microsoft.EntityFrameworkCore;

namespace ECommerceApp.Repositories
{
    public class CategoryRepository : Repository<Category>, ICategoryRepository
    {
        public CategoryRepository(ApplicationDbContext context) : base(context)
        {
        }

        public async Task<Category?> GetBySlugAsync(string slug)
        {
            return await _dbSet
                .AsNoTracking()
                .FirstOrDefaultAsync(c => c.Slug == slug && c.IsActive);
        }

        public async Task<Category?> GetBySlugWithProductsAsync(string slug)
        {
            return await _dbSet
                .AsNoTracking()
                .Include(c => c.Products.Where(p => p.IsActive))
                .ThenInclude(p => p.Images)
                .FirstOrDefaultAsync(c => c.Slug == slug && c.IsActive);
        }

        public async Task<IEnumerable<Category>> GetActiveCategoriesAsync()
        {
            return await _dbSet
                .AsNoTracking()
                .Where(c => c.IsActive)
                .OrderBy(c => c.DisplayOrder)
                .ThenBy(c => c.Name)
                .ToListAsync();
        }

        public async Task<IEnumerable<Category>> GetActiveCategoriesWithProductsAsync(int maxProductsPerCategory)
        {
            var categories = await _dbSet
                .AsNoTracking()
                .Where(c => c.IsActive)
                .OrderBy(c => c.DisplayOrder)
                .ThenBy(c => c.Name)
                .Take(10)
                .ToListAsync();

            foreach (var category in categories)
            {
                var products = await _context.Products
                    .AsNoTracking()
                    .Where(p => p.CategoryId == category.Id && p.IsActive)
                    .Include(p => p.Images)
                    .OrderByDescending(p => p.CreatedAt)
                    .Take(maxProductsPerCategory)
                    .ToListAsync();

                category.Products = products;
            }

            return categories;
        }

        public async Task<IEnumerable<Category>> GetParentCategoriesAsync()
        {
            return await _dbSet
                .AsNoTracking()
                .Where(c => c.ParentCategoryId == null && c.IsActive)
                .OrderBy(c => c.DisplayOrder)
                .ThenBy(c => c.Name)
                .ToListAsync();
        }

        public async Task<bool> SlugExistsAsync(string slug, int? excludeId = null)
        {
            if (excludeId.HasValue)
            {
                return await _dbSet.AnyAsync(c => c.Slug == slug && c.Id != excludeId.Value);
            }
            return await _dbSet.AnyAsync(c => c.Slug == slug);
        }

        public async Task<int> GetProductCountAsync(int categoryId)
        {
            return await _context.Products
                .AsNoTracking()
                .CountAsync(p => p.CategoryId == categoryId && p.IsActive);
        }
    }
}
