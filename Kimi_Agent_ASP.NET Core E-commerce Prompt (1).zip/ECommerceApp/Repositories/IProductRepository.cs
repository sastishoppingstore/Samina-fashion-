using ECommerceApp.Models;

namespace ECommerceApp.Repositories
{
    public interface IProductRepository : IRepository<Product>
    {
        Task<Product?> GetBySlugAsync(string slug);
        Task<Product?> GetBySlugWithDetailsAsync(string slug);
        Task<IEnumerable<Product>> GetActiveProductsAsync();
        Task<IEnumerable<Product>> GetProductsByCategoryAsync(int categoryId);
        Task<IEnumerable<Product>> GetFeaturedProductsAsync(int count);
        Task<IEnumerable<Product>> GetLatestProductsAsync(int count);
        Task<IEnumerable<Product>> SearchProductsAsync(string searchTerm);
        Task<IEnumerable<Product>> GetLowStockProductsAsync();
        Task<IEnumerable<Product>> GetOutOfStockProductsAsync();
        Task<bool> SlugExistsAsync(string slug, int? excludeId = null);
        Task IncrementViewCountAsync(int productId);
        Task<(IEnumerable<Product> Products, int TotalCount)> GetPagedProductsAsync(
            int page, 
            int pageSize, 
            int? categoryId = null, 
            string? searchTerm = null, 
            bool? isActive = null,
            bool? isFeatured = null);
    }
}
