using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ECommerceApp.Models
{
    public class Product
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(200)]
        public string Name { get; set; } = string.Empty;

        [Required]
        [StringLength(250)]
        public string Slug { get; set; } = string.Empty;

        [Required]
        [StringLength(500)]
        public string ShortDescription { get; set; } = string.Empty;

        [Required]
        public string FullDescription { get; set; } = string.Empty;

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal Price { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? CompareAtPrice { get; set; }

        public int StockQuantity { get; set; } = 0;
        public int StockThreshold { get; set; } = 5;

        [StringLength(150)]
        public string? MetaTitle { get; set; }

        [StringLength(300)]
        public string? MetaDescription { get; set; }

        [StringLength(500)]
        public string? Keywords { get; set; }

        [Required]
        public int CategoryId { get; set; }

        [ForeignKey("CategoryId")]
        public virtual Category Category { get; set; } = null!;

        public virtual ICollection<ProductImage> Images { get; set; } = new List<ProductImage>();
        public virtual ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();

        public bool IsActive { get; set; } = true;
        public bool IsFeatured { get; set; } = false;
        public int ViewCount { get; set; } = 0;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime? UpdatedAt { get; set; }

        [NotMapped]
        public decimal? DiscountPercentage
        {
            get
            {
                if (CompareAtPrice.HasValue && CompareAtPrice > Price)
                {
                    return Math.Round(((CompareAtPrice.Value - Price) / CompareAtPrice.Value) * 100, 0);
                }
                return null;
            }
        }

        [NotMapped]
        public string PrimaryImageUrl => Images?.FirstOrDefault(i => i.IsPrimary)?.ImageUrl 
            ?? Images?.FirstOrDefault()?.ImageUrl 
            ?? "/images/no-image.jpg";

        [NotMapped]
        public bool IsLowStock => StockQuantity <= StockThreshold && StockQuantity > 0;

        [NotMapped]
        public bool IsOutOfStock => StockQuantity <= 0;
    }
}
