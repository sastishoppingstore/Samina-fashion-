-- E-Commerce Database Schema
-- Run this script to create the database and tables

-- Create Database
IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'ECommerceDB')
BEGIN
    CREATE DATABASE ECommerceDB;
END
GO

USE ECommerceDB;
GO

-- AspNetUsers Table (Created by Identity)
-- AspNetRoles Table (Created by Identity)
-- AspNetUserRoles Table (Created by Identity)
-- AspNetUserClaims Table (Created by Identity)
-- AspNetUserLogins Table (Created by Identity)
-- AspNetUserTokens Table (Created by Identity)
-- AspNetRoleClaims Table (Created by Identity)

-- Categories Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Categories')
BEGIN
    CREATE TABLE Categories (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Name NVARCHAR(100) NOT NULL,
        Slug NVARCHAR(150) NOT NULL UNIQUE,
        Description NVARCHAR(500) NULL,
        ImageUrl NVARCHAR(255) NULL,
        MetaTitle NVARCHAR(150) NULL,
        MetaDescription NVARCHAR(300) NULL,
        ParentCategoryId INT NULL,
        DisplayOrder INT NOT NULL DEFAULT 0,
        IsActive BIT NOT NULL DEFAULT 1,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        UpdatedAt DATETIME2 NULL,
        CONSTRAINT FK_Categories_ParentCategory FOREIGN KEY (ParentCategoryId) REFERENCES Categories(Id) ON DELETE NO ACTION
    );
END
GO

-- Create Index on Categories
CREATE NONCLUSTERED INDEX IX_Categories_Slug ON Categories(Slug);
CREATE NONCLUSTERED INDEX IX_Categories_IsActive ON Categories(IsActive);
CREATE NONCLUSTERED INDEX IX_Categories_DisplayOrder ON Categories(DisplayOrder);
GO

-- Products Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Products')
BEGIN
    CREATE TABLE Products (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Name NVARCHAR(200) NOT NULL,
        Slug NVARCHAR(250) NOT NULL UNIQUE,
        ShortDescription NVARCHAR(500) NOT NULL,
        FullDescription NVARCHAR(MAX) NOT NULL,
        Price DECIMAL(18,2) NOT NULL,
        CompareAtPrice DECIMAL(18,2) NULL,
        StockQuantity INT NOT NULL DEFAULT 0,
        StockThreshold INT NOT NULL DEFAULT 5,
        MetaTitle NVARCHAR(150) NULL,
        MetaDescription NVARCHAR(300) NULL,
        Keywords NVARCHAR(500) NULL,
        CategoryId INT NOT NULL,
        IsActive BIT NOT NULL DEFAULT 1,
        IsFeatured BIT NOT NULL DEFAULT 0,
        ViewCount INT NOT NULL DEFAULT 0,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        UpdatedAt DATETIME2 NULL,
        CONSTRAINT FK_Products_Category FOREIGN KEY (CategoryId) REFERENCES Categories(Id) ON DELETE NO ACTION
    );
END
GO

-- Create Index on Products
CREATE NONCLUSTERED INDEX IX_Products_Slug ON Products(Slug);
CREATE NONCLUSTERED INDEX IX_Products_IsActive ON Products(IsActive);
CREATE NONCLUSTERED INDEX IX_Products_IsFeatured ON Products(IsFeatured);
CREATE NONCLUSTERED INDEX IX_Products_CategoryId ON Products(CategoryId);
CREATE NONCLUSTERED INDEX IX_Products_Price ON Products(Price);
CREATE NONCLUSTERED INDEX IX_Products_CreatedAt ON Products(CreatedAt);
GO

-- ProductImages Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'ProductImages')
BEGIN
    CREATE TABLE ProductImages (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        ProductId INT NOT NULL,
        ImageUrl NVARCHAR(500) NOT NULL,
        AltText NVARCHAR(255) NULL,
        DisplayOrder INT NOT NULL DEFAULT 0,
        IsPrimary BIT NOT NULL DEFAULT 0,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        CONSTRAINT FK_ProductImages_Product FOREIGN KEY (ProductId) REFERENCES Products(Id) ON DELETE CASCADE
    );
END
GO

-- Create Index on ProductImages
CREATE NONCLUSTERED INDEX IX_ProductImages_ProductId ON ProductImages(ProductId);
CREATE NONCLUSTERED INDEX IX_ProductImages_IsPrimary ON ProductImages(IsPrimary);
GO

-- Orders Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'Orders')
BEGIN
    CREATE TABLE Orders (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        OrderNumber NVARCHAR(20) NOT NULL UNIQUE,
        UserId NVARCHAR(450) NULL,
        CustomerName NVARCHAR(100) NOT NULL,
        CustomerEmail NVARCHAR(100) NOT NULL,
        CustomerPhone NVARCHAR(20) NOT NULL,
        ShippingAddress NVARCHAR(200) NOT NULL,
        ShippingCity NVARCHAR(100) NOT NULL,
        ShippingPostalCode NVARCHAR(20) NULL,
        ShippingCountry NVARCHAR(100) NULL,
        OrderNotes NVARCHAR(500) NULL,
        SubTotal DECIMAL(18,2) NOT NULL,
        ShippingCost DECIMAL(18,2) NOT NULL DEFAULT 0,
        TaxAmount DECIMAL(18,2) NOT NULL DEFAULT 0,
        DiscountAmount DECIMAL(18,2) NOT NULL DEFAULT 0,
        TotalAmount DECIMAL(18,2) NOT NULL,
        OrderStatus INT NOT NULL DEFAULT 0,
        PaymentStatus INT NOT NULL DEFAULT 0,
        PaymentMethod INT NOT NULL DEFAULT 0,
        PaidAt DATETIME2 NULL,
        ShippedAt DATETIME2 NULL,
        DeliveredAt DATETIME2 NULL,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        UpdatedAt DATETIME2 NULL
    );
END
GO

-- Create Index on Orders
CREATE NONCLUSTERED INDEX IX_Orders_OrderNumber ON Orders(OrderNumber);
CREATE NONCLUSTERED INDEX IX_Orders_UserId ON Orders(UserId);
CREATE NONCLUSTERED INDEX IX_Orders_OrderStatus ON Orders(OrderStatus);
CREATE NONCLUSTERED INDEX IX_Orders_PaymentStatus ON Orders(PaymentStatus);
CREATE NONCLUSTERED INDEX IX_Orders_CreatedAt ON Orders(CreatedAt);
GO

-- OrderItems Table
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'OrderItems')
BEGIN
    CREATE TABLE OrderItems (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        OrderId INT NOT NULL,
        ProductId INT NOT NULL,
        ProductName NVARCHAR(200) NOT NULL,
        ProductImageUrl NVARCHAR(500) NULL,
        UnitPrice DECIMAL(18,2) NOT NULL,
        Quantity INT NOT NULL,
        Discount DECIMAL(18,2) NOT NULL DEFAULT 0,
        CreatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
        CONSTRAINT FK_OrderItems_Order FOREIGN KEY (OrderId) REFERENCES Orders(Id) ON DELETE CASCADE,
        CONSTRAINT FK_OrderItems_Product FOREIGN KEY (ProductId) REFERENCES Products(Id) ON DELETE NO ACTION
    );
END
GO

-- Create Index on OrderItems
CREATE NONCLUSTERED INDEX IX_OrderItems_OrderId ON OrderItems(OrderId);
CREATE NONCLUSTERED INDEX IX_OrderItems_ProductId ON OrderItems(ProductId);
GO

-- Insert Sample Categories (Optional - for testing)
/*
INSERT INTO Categories (Name, Slug, Description, DisplayOrder, IsActive) VALUES
('Electronics', 'electronics', 'Latest electronic gadgets and devices', 1, 1),
('Fashion', 'fashion', 'Trendy clothing and accessories', 2, 1),
('Home & Garden', 'home-garden', 'Everything for your home and garden', 3, 1),
('Sports & Outdoors', 'sports-outdoors', 'Sports equipment and outdoor gear', 4, 1),
('Books', 'books', 'Physical and digital books', 5, 1);
GO
*/

PRINT 'Database schema created successfully!';
GO
