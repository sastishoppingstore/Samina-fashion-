using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Processing;

namespace ECommerceApp.Services
{
    public class FileUploadService : IFileUploadService
    {
        private readonly IWebHostEnvironment _environment;
        private readonly IConfiguration _configuration;
        private readonly string[] _allowedExtensions;
        private readonly long _maxFileSize;

        public FileUploadService(IWebHostEnvironment environment, IConfiguration configuration)
        {
            _environment = environment;
            _configuration = configuration;
            _allowedExtensions = configuration.GetSection("FileUpload:AllowedExtensions")
                .Get<string[]>() ?? new[] { ".jpg", ".jpeg", ".png", ".webp" };
            _maxFileSize = configuration.GetValue<long>("FileUpload:MaxFileSizeMB", 5) * 1024 * 1024;
        }

        public async Task<string> UploadProductImageAsync(IFormFile file)
        {
            var folder = _configuration.GetValue<string>("FileUpload:ProductImagePath", "uploads/products");
            return await UploadImageAsync(file, folder);
        }

        public async Task<string> UploadCategoryImageAsync(IFormFile file)
        {
            var folder = _configuration.GetValue<string>("FileUpload:CategoryImagePath", "uploads/categories");
            return await UploadImageAsync(file, folder);
        }

        public async Task<string> UploadImageAsync(IFormFile file, string folder)
        {
            if (!IsValidImageFile(file))
            {
                throw new InvalidOperationException("Invalid image file.");
            }

            var uploadsFolder = Path.Combine(_environment.WebRootPath, folder);
            if (!Directory.Exists(uploadsFolder))
            {
                Directory.CreateDirectory(uploadsFolder);
            }

            var fileName = $"{Guid.NewGuid()}{Path.GetExtension(file.FileName)}";
            var filePath = Path.Combine(uploadsFolder, fileName);

            // Process and optimize image
            using (var image = await Image.LoadAsync(file.OpenReadStream()))
            {
                // Resize if too large
                if (image.Width > 1200 || image.Height > 1200)
                {
                    image.Mutate(x => x.Resize(new ResizeOptions
                    {
                        Mode = ResizeMode.Max,
                        Size = new Size(1200, 1200)
                    }));
                }

                // Save as WebP for better compression
                var webpFileName = Path.ChangeExtension(fileName, ".webp");
                var webpFilePath = Path.Combine(uploadsFolder, webpFileName);
                
                await image.SaveAsWebpAsync(webpFilePath, new SixLabors.ImageSharp.Formats.Webp.WebpEncoder
                {
                    Quality = 85,
                    FileFormat = SixLabors.ImageSharp.Formats.Webp.WebpFileFormatType.Lossy
                });

                return $"/{folder}/{webpFileName}";
            }
        }

        public void DeleteImage(string imageUrl)
        {
            if (string.IsNullOrEmpty(imageUrl)) return;

            var filePath = Path.Combine(_environment.WebRootPath, imageUrl.TrimStart('/').Replace('/', Path.DirectorySeparatorChar));
            if (File.Exists(filePath))
            {
                File.Delete(filePath);
            }
        }

        public bool IsValidImageFile(IFormFile file)
        {
            if (file == null || file.Length == 0)
                return false;

            if (file.Length > _maxFileSize)
                return false;

            var extension = Path.GetExtension(file.FileName).ToLowerInvariant();
            return _allowedExtensions.Contains(extension);
        }
    }
}
