using ECommerceApp.Models;
using ECommerceApp.Models.ViewModels;

namespace ECommerceApp.Services
{
    public interface IShoppingCartService
    {
        Task<ShoppingCart> GetCartAsync(string sessionId);
        Task AddToCartAsync(string sessionId, int productId, int quantity);
        Task RemoveFromCartAsync(string sessionId, int productId);
        Task UpdateQuantityAsync(string sessionId, int productId, int quantity);
        Task ClearCartAsync(string sessionId);
        Task<CartViewModel> GetCartViewModelAsync(string sessionId);
        Task<int> GetCartItemCountAsync(string sessionId);
    }
}
