using ECommerceApp.Models;
using ECommerceApp.Models.ViewModels;
using ECommerceApp.Repositories;

namespace ECommerceApp.Services
{
    public class CategoryService : ICategoryService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IFileUploadService _fileUploadService;
        private readonly IConfiguration _configuration;

        public CategoryService(
            IUnitOfWork unitOfWork, 
            IFileUploadService fileUploadService,
            IConfiguration configuration)
        {
            _unitOfWork = unitOfWork;
            _fileUploadService = fileUploadService;
            _configuration = configuration;
        }

        public async Task<IEnumerable<CategoryViewModel>> GetAllCategoriesAsync()
        {
            var categories = await _unitOfWork.Categories.GetAllAsync();
            return categories.Select(MapToViewModel);
        }

        public async Task<IEnumerable<CategoryViewModel>> GetActiveCategoriesAsync()
        {
            var categories = await _unitOfWork.Categories.GetActiveCategoriesAsync();
            return categories.Select(MapToViewModel);
        }

        public async Task<IEnumerable<CategoryDropdownViewModel>> GetCategoriesForDropdownAsync()
        {
            var categories = await _unitOfWork.Categories.GetActiveCategoriesAsync();
            return categories.Select(c => new CategoryDropdownViewModel
            {
                Id = c.Id,
                Name = c.Name
            });
        }

        public async Task<CategoryViewModel?> GetCategoryByIdAsync(int id)
        {
            var category = await _unitOfWork.Categories.GetByIdAsync(id);
            return category != null ? MapToViewModel(category) : null;
        }

        public async Task<CategoryViewModel?> GetCategoryBySlugAsync(string slug)
        {
            var category = await _unitOfWork.Categories.GetBySlugAsync(slug);
            return category != null ? MapToViewModel(category) : null;
        }

        public async Task<CategoryWithProductsViewModel?> GetCategoryWithProductsAsync(string slug)
        {
            var category = await _unitOfWork.Categories.GetBySlugWithProductsAsync(slug);
            if (category == null) return null;

            return new CategoryWithProductsViewModel
            {
                Id = category.Id,
                Name = category.Name,
                Slug = category.Slug,
                Description = category.Description,
                ImageUrl = category.ImageUrl,
                Products = category.Products.Select(p => new ProductListViewModel
                {
                    Id = p.Id,
                    Name = p.Name,
                    Slug = p.Slug,
                    ShortDescription = p.ShortDescription,
                    Price = p.Price,
                    CompareAtPrice = p.CompareAtPrice,
                    DiscountPercentage = p.DiscountPercentage,
                    PrimaryImageUrl = p.PrimaryImageUrl,
                    CategoryName = category.Name,
                    CategorySlug = category.Slug,
                    IsLowStock = p.IsLowStock,
                    IsOutOfStock = p.IsOutOfStock,
                    IsFeatured = p.IsFeatured
                }).ToList()
            };
        }

        public async Task<IEnumerable<CategorySectionViewModel>> GetHomepageCategorySectionsAsync()
        {
            var maxCategories = _configuration.GetValue<int>("AppSettings:MaxHomepageCategories", 10);
            var maxProducts = _configuration.GetValue<int>("AppSettings:MaxProductsPerCategory", 10);

            var categories = await _unitOfWork.Categories.GetActiveCategoriesWithProductsAsync(maxProducts);
            
            return categories.Take(maxCategories).Select(c => new CategorySectionViewModel
            {
                Id = c.Id,
                Name = c.Name,
                Slug = c.Slug,
                ImageUrl = c.ImageUrl,
                Products = c.Products.Select(p => new ProductListViewModel
                {
                    Id = p.Id,
                    Name = p.Name,
                    Slug = p.Slug,
                    ShortDescription = p.ShortDescription,
                    Price = p.Price,
                    CompareAtPrice = p.CompareAtPrice,
                    DiscountPercentage = p.DiscountPercentage,
                    PrimaryImageUrl = p.PrimaryImageUrl,
                    CategoryName = c.Name,
                    CategorySlug = c.Slug,
                    IsLowStock = p.IsLowStock,
                    IsOutOfStock = p.IsOutOfStock,
                    IsFeatured = p.IsFeatured
                }).ToList()
            });
        }

        public async Task<CategoryViewModel> CreateCategoryAsync(CategoryViewModel model)
        {
            var slug = await GenerateSlugAsync(model.Name);
            
            string? imageUrl = null;
            if (model.ImageFile != null)
            {
                imageUrl = await _fileUploadService.UploadCategoryImageAsync(model.ImageFile);
            }

            var category = new Category
            {
                Name = model.Name,
                Slug = slug,
                Description = model.Description,
                ImageUrl = imageUrl,
                MetaTitle = model.MetaTitle,
                MetaDescription = model.MetaDescription,
                ParentCategoryId = model.ParentCategoryId,
                DisplayOrder = model.DisplayOrder,
                IsActive = model.IsActive,
                CreatedAt = DateTime.UtcNow
            };

            await _unitOfWork.Categories.AddAsync(category);
            await _unitOfWork.SaveChangesAsync();

            return MapToViewModel(category);
        }

        public async Task<CategoryViewModel?> UpdateCategoryAsync(CategoryViewModel model)
        {
            var category = await _unitOfWork.Categories.GetByIdAsync(model.Id);
            if (category == null) return null;

            category.Name = model.Name;
            category.Description = model.Description;
            category.MetaTitle = model.MetaTitle;
            category.MetaDescription = model.MetaDescription;
            category.ParentCategoryId = model.ParentCategoryId;
            category.DisplayOrder = model.DisplayOrder;
            category.IsActive = model.IsActive;
            category.UpdatedAt = DateTime.UtcNow;

            if (model.ImageFile != null)
            {
                if (!string.IsNullOrEmpty(category.ImageUrl))
                {
                    _fileUploadService.DeleteImage(category.ImageUrl);
                }
                category.ImageUrl = await _fileUploadService.UploadCategoryImageAsync(model.ImageFile);
            }

            _unitOfWork.Categories.Update(category);
            await _unitOfWork.SaveChangesAsync();

            return MapToViewModel(category);
        }

        public async Task<bool> DeleteCategoryAsync(int id)
        {
            var category = await _unitOfWork.Categories.GetByIdAsync(id);
            if (category == null) return false;

            var productCount = await _unitOfWork.Categories.GetProductCountAsync(id);
            if (productCount > 0)
            {
                throw new InvalidOperationException("Cannot delete category with existing products.");
            }

            if (!string.IsNullOrEmpty(category.ImageUrl))
            {
                _fileUploadService.DeleteImage(category.ImageUrl);
            }

            _unitOfWork.Categories.Remove(category);
            await _unitOfWork.SaveChangesAsync();
            return true;
        }

        public async Task<bool> CategoryExistsAsync(int id)
        {
            return await _unitOfWork.Categories.AnyAsync(c => c.Id == id);
        }

        public async Task<string> GenerateSlugAsync(string name, int? excludeId = null)
        {
            var slug = SlugGenerator.GenerateSlug(name);
            var originalSlug = slug;
            var counter = 1;

            while (await _unitOfWork.Categories.SlugExistsAsync(slug, excludeId))
            {
                slug = $"{originalSlug}-{counter}";
                counter++;
            }

            return slug;
        }

        private CategoryViewModel MapToViewModel(Category category)
        {
            return new CategoryViewModel
            {
                Id = category.Id,
                Name = category.Name,
                Description = category.Description,
                ImageUrl = category.ImageUrl,
                MetaTitle = category.MetaTitle,
                MetaDescription = category.MetaDescription,
                ParentCategoryId = category.ParentCategoryId,
                DisplayOrder = category.DisplayOrder,
                IsActive = category.IsActive,
                CreatedAt = category.CreatedAt
            };
        }
    }
}
