namespace ECommerceApp.Services
{
    public interface IFileUploadService
    {
        Task<string> UploadProductImageAsync(IFormFile file);
        Task<string> UploadCategoryImageAsync(IFormFile file);
        Task<string> UploadImageAsync(IFormFile file, string folder);
        void DeleteImage(string imageUrl);
        bool IsValidImageFile(IFormFile file);
    }
}
