using ECommerceApp.Models;
using ECommerceApp.Models.ViewModels;

namespace ECommerceApp.Services
{
    public interface IOrderService
    {
        Task<OrderViewModel?> GetOrderByIdAsync(int id);
        Task<OrderViewModel?> GetOrderByNumberAsync(string orderNumber);
        Task<IEnumerable<OrderViewModel>> GetOrdersByUserIdAsync(string userId);
        Task<(IEnumerable<OrderViewModel> Orders, int TotalCount)> GetPagedOrdersAsync(
            int page, int pageSize, OrderStatus? status = null, 
            DateTime? fromDate = null, DateTime? toDate = null, string? searchTerm = null);
        Task<OrderConfirmationViewModel> CreateOrderAsync(CheckoutViewModel model, ShoppingCart cart);
        Task<bool> UpdateOrderStatusAsync(int orderId, OrderStatus status);
        Task<bool> UpdatePaymentStatusAsync(int orderId, PaymentStatus status);
        Task<bool> CancelOrderAsync(int orderId);
        Task<IEnumerable<OrderViewModel>> GetRecentOrdersAsync(int count);
        Task<byte[]> ExportOrdersToCsvAsync(OrderFilterViewModel filter);
        Task<string> GenerateOrderNumberAsync();
    }
}
