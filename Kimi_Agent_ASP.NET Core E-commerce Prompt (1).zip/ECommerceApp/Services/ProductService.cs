using ECommerceApp.Models;
using ECommerceApp.Models.ViewModels;
using ECommerceApp.Repositories;

namespace ECommerceApp.Services
{
    public class ProductService : IProductService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IFileUploadService _fileUploadService;

        public ProductService(IUnitOfWork unitOfWork, IFileUploadService fileUploadService)
        {
            _unitOfWork = unitOfWork;
            _fileUploadService = fileUploadService;
        }

        public async Task<IEnumerable<ProductListViewModel>> GetAllProductsAsync()
        {
            var products = await _unitOfWork.Products.GetAllAsync();
            return products.Select(MapToListViewModel);
        }

        public async Task<IEnumerable<ProductListViewModel>> GetActiveProductsAsync()
        {
            var products = await _unitOfWork.Products.GetActiveProductsAsync();
            return products.Select(MapToListViewModel);
        }

        public async Task<IEnumerable<ProductListViewModel>> GetFeaturedProductsAsync(int count)
        {
            var products = await _unitOfWork.Products.GetFeaturedProductsAsync(count);
            return products.Select(MapToListViewModel);
        }

        public async Task<IEnumerable<ProductListViewModel>> GetLatestProductsAsync(int count)
        {
            var products = await _unitOfWork.Products.GetLatestProductsAsync(count);
            return products.Select(MapToListViewModel);
        }

        public async Task<ProductViewModel?> GetProductByIdAsync(int id)
        {
            var product = await _unitOfWork.Products.GetByIdAsync(id, p => p.Images, p => p.Category);
            if (product == null) return null;

            return MapToViewModel(product);
        }

        public async Task<ProductDetailViewModel?> GetProductBySlugAsync(string slug)
        {
            var product = await _unitOfWork.Products.GetBySlugWithDetailsAsync(slug);
            if (product == null) return null;

            await _unitOfWork.Products.IncrementViewCountAsync(product.Id);

            var relatedProducts = await _unitOfWork.Products.GetProductsByCategoryAsync(product.CategoryId);
            relatedProducts = relatedProducts.Where(p => p.Id != product.Id).Take(4);

            return new ProductDetailViewModel
            {
                Id = product.Id,
                Name = product.Name,
                Slug = product.Slug,
                ShortDescription = product.ShortDescription,
                FullDescription = product.FullDescription,
                Price = product.Price,
                CompareAtPrice = product.CompareAtPrice,
                DiscountPercentage = product.DiscountPercentage,
                StockQuantity = product.StockQuantity,
                IsLowStock = product.IsLowStock,
                IsOutOfStock = product.IsOutOfStock,
                MetaTitle = product.MetaTitle,
                MetaDescription = product.MetaDescription,
                Keywords = product.Keywords,
                CategoryId = product.CategoryId,
                CategoryName = product.Category?.Name ?? string.Empty,
                CategorySlug = product.Category?.Slug ?? string.Empty,
                Images = product.Images.Select(i => new ProductImageViewModel
                {
                    Id = i.Id,
                    ImageUrl = i.ImageUrl,
                    AltText = i.AltText,
                    DisplayOrder = i.DisplayOrder,
                    IsPrimary = i.IsPrimary
                }).ToList(),
                RelatedProducts = relatedProducts.Select(MapToListViewModel).ToList()
            };
        }

        public async Task<IEnumerable<ProductListViewModel>> GetProductsByCategoryAsync(int categoryId)
        {
            var products = await _unitOfWork.Products.GetProductsByCategoryAsync(categoryId);
            return products.Select(MapToListViewModel);
        }

        public async Task<IEnumerable<ProductListViewModel>> SearchProductsAsync(string searchTerm)
        {
            var products = await _unitOfWork.Products.SearchProductsAsync(searchTerm);
            return products.Select(MapToListViewModel);
        }

        public async Task<ProductViewModel> CreateProductAsync(ProductViewModel model)
        {
            var slug = await GenerateSlugAsync(model.Name);

            var product = new Product
            {
                Name = model.Name,
                Slug = slug,
                ShortDescription = model.ShortDescription,
                FullDescription = model.FullDescription,
                Price = model.Price,
                CompareAtPrice = model.CompareAtPrice,
                StockQuantity = model.StockQuantity,
                StockThreshold = model.StockThreshold,
                MetaTitle = model.MetaTitle,
                MetaDescription = model.MetaDescription,
                Keywords = model.Keywords,
                CategoryId = model.CategoryId,
                IsActive = model.IsActive,
                IsFeatured = model.IsFeatured,
                CreatedAt = DateTime.UtcNow
            };

            await _unitOfWork.Products.AddAsync(product);
            await _unitOfWork.SaveChangesAsync();

            if (model.ImageFiles != null && model.ImageFiles.Any())
            {
                foreach (var file in model.ImageFiles)
                {
                    var imageUrl = await _fileUploadService.UploadProductImageAsync(file);
                    var productImage = new ProductImage
                    {
                        ProductId = product.Id,
                        ImageUrl = imageUrl,
                        AltText = product.Name,
                        IsPrimary = !product.Images.Any(),
                        DisplayOrder = product.Images.Count
                    };
                    await _unitOfWork.ProductImages.AddAsync(productImage);
                }
                await _unitOfWork.SaveChangesAsync();
            }

            return MapToViewModel(product);
        }

        public async Task<ProductViewModel?> UpdateProductAsync(ProductViewModel model)
        {
            var product = await _unitOfWork.Products.GetByIdAsync(model.Id, p => p.Images);
            if (product == null) return null;

            product.Name = model.Name;
            product.ShortDescription = model.ShortDescription;
            product.FullDescription = model.FullDescription;
            product.Price = model.Price;
            product.CompareAtPrice = model.CompareAtPrice;
            product.StockQuantity = model.StockQuantity;
            product.StockThreshold = model.StockThreshold;
            product.MetaTitle = model.MetaTitle;
            product.MetaDescription = model.MetaDescription;
            product.Keywords = model.Keywords;
            product.CategoryId = model.CategoryId;
            product.IsActive = model.IsActive;
            product.IsFeatured = model.IsFeatured;
            product.UpdatedAt = DateTime.UtcNow;

            if (model.ImageFiles != null && model.ImageFiles.Any())
            {
                foreach (var file in model.ImageFiles)
                {
                    var imageUrl = await _fileUploadService.UploadProductImageAsync(file);
                    var productImage = new ProductImage
                    {
                        ProductId = product.Id,
                        ImageUrl = imageUrl,
                        AltText = product.Name,
                        IsPrimary = !product.Images.Any(i => i.IsPrimary),
                        DisplayOrder = product.Images.Count
                    };
                    await _unitOfWork.ProductImages.AddAsync(productImage);
                }
            }

            _unitOfWork.Products.Update(product);
            await _unitOfWork.SaveChangesAsync();

            return MapToViewModel(product);
        }

        public async Task<bool> DeleteProductAsync(int id)
        {
            var product = await _unitOfWork.Products.GetByIdAsync(id, p => p.Images);
            if (product == null) return false;

            foreach (var image in product.Images)
            {
                _fileUploadService.DeleteImage(image.ImageUrl);
            }

            _unitOfWork.Products.Remove(product);
            await _unitOfWork.SaveChangesAsync();
            return true;
        }

        public async Task<bool> ToggleActiveAsync(int id)
        {
            var product = await _unitOfWork.Products.GetByIdAsync(id);
            if (product == null) return false;

            product.IsActive = !product.IsActive;
            product.UpdatedAt = DateTime.UtcNow;
            _unitOfWork.Products.Update(product);
            await _unitOfWork.SaveChangesAsync();
            return true;
        }

        public async Task<bool> ToggleFeaturedAsync(int id)
        {
            var product = await _unitOfWork.Products.GetByIdAsync(id);
            if (product == null) return false;

            product.IsFeatured = !product.IsFeatured;
            product.UpdatedAt = DateTime.UtcNow;
            _unitOfWork.Products.Update(product);
            await _unitOfWork.SaveChangesAsync();
            return true;
        }

        public async Task<bool> ProductExistsAsync(int id)
        {
            return await _unitOfWork.Products.AnyAsync(p => p.Id == id);
        }

        public async Task<string> GenerateSlugAsync(string name, int? excludeId = null)
        {
            var slug = SlugGenerator.GenerateSlug(name);
            var originalSlug = slug;
            var counter = 1;

            while (await _unitOfWork.Products.SlugExistsAsync(slug, excludeId))
            {
                slug = $"{originalSlug}-{counter}";
                counter++;
            }

            return slug;
        }

        public async Task<(IEnumerable<ProductListViewModel> Products, int TotalCount)> GetPagedProductsAsync(
            int page, int pageSize, int? categoryId = null, string? searchTerm = null, 
            bool? isActive = null, bool? isFeatured = null)
        {
            var (products, totalCount) = await _unitOfWork.Products.GetPagedProductsAsync(
                page, pageSize, categoryId, searchTerm, isActive, isFeatured);
            
            return (products.Select(MapToListViewModel), totalCount);
        }

        private ProductListViewModel MapToListViewModel(Product product)
        {
            return new ProductListViewModel
            {
                Id = product.Id,
                Name = product.Name,
                Slug = product.Slug,
                ShortDescription = product.ShortDescription,
                Price = product.Price,
                CompareAtPrice = product.CompareAtPrice,
                DiscountPercentage = product.DiscountPercentage,
                PrimaryImageUrl = product.PrimaryImageUrl,
                CategoryName = product.Category?.Name ?? string.Empty,
                CategorySlug = product.Category?.Slug ?? string.Empty,
                IsLowStock = product.IsLowStock,
                IsOutOfStock = product.IsOutOfStock,
                IsFeatured = product.IsFeatured
            };
        }

        private ProductViewModel MapToViewModel(Product product)
        {
            return new ProductViewModel
            {
                Id = product.Id,
                Name = product.Name,
                ShortDescription = product.ShortDescription,
                FullDescription = product.FullDescription,
                Price = product.Price,
                CompareAtPrice = product.CompareAtPrice,
                StockQuantity = product.StockQuantity,
                StockThreshold = product.StockThreshold,
                MetaTitle = product.MetaTitle,
                MetaDescription = product.MetaDescription,
                Keywords = product.Keywords,
                CategoryId = product.CategoryId,
                CategoryName = product.Category?.Name,
                Images = product.Images?.Select(i => new ProductImageViewModel
                {
                    Id = i.Id,
                    ImageUrl = i.ImageUrl,
                    AltText = i.AltText,
                    DisplayOrder = i.DisplayOrder,
                    IsPrimary = i.IsPrimary
                }).ToList() ?? new List<ProductImageViewModel>(),
                IsActive = product.IsActive,
                IsFeatured = product.IsFeatured,
                ViewCount = product.ViewCount,
                CreatedAt = product.CreatedAt,
                UpdatedAt = product.UpdatedAt
            };
        }
    }
}
