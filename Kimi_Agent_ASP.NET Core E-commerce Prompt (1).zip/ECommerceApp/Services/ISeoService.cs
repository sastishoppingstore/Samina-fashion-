using ECommerceApp.Models.ViewModels;

namespace ECommerceApp.Services
{
    public interface ISeoService
    {
        SeoMetaData GetHomepageSeoData();
        SeoMetaData GetProductSeoData(ProductDetailViewModel product);
        SeoMetaData GetCategorySeoData(CategoryWithProductsViewModel category);
        string GenerateStructuredDataProduct(ProductDetailViewModel product);
        string GenerateStructuredDataOrganization();
        string GenerateBreadcrumbJsonLd(List<BreadcrumbItem> breadcrumbs);
    }

    public class SeoMetaData
    {
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Keywords { get; set; } = string.Empty;
        public string CanonicalUrl { get; set; } = string.Empty;
        public string OgTitle { get; set; } = string.Empty;
        public string OgDescription { get; set; } = string.Empty;
        public string OgImage { get; set; } = string.Empty;
        public string OgType { get; set; } = "website";
    }

    public class BreadcrumbItem
    {
        public string Name { get; set; } = string.Empty;
        public string Url { get; set; } = string.Empty;
    }
}
