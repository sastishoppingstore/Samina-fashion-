using ECommerceApp.Models.ViewModels;
using System.Text.Json;

namespace ECommerceApp.Services
{
    public class SeoService : ISeoService
    {
        private readonly IConfiguration _configuration;

        public SeoService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public SeoMetaData GetHomepageSeoData()
        {
            var siteName = _configuration.GetValue<string>("AppSettings:SiteName", "E-Commerce Store");
            var siteUrl = _configuration.GetValue<string>("AppSettings:SiteUrl", "https://yourdomain.com");

            return new SeoMetaData
            {
                Title = $"{siteName} - Your One-Stop Online Shopping Destination",
                Description = $"Welcome to {siteName}. Discover amazing products at great prices. Shop now for the best deals on electronics, fashion, home goods, and more.",
                Keywords = "online shopping, e-commerce, best deals, electronics, fashion, home goods",
                CanonicalUrl = siteUrl,
                OgTitle = siteName,
                OgDescription = $"Discover amazing products at {siteName}. Shop now for the best deals!",
                OgImage = $"{siteUrl}/images/og-image.jpg",
                OgType = "website"
            };
        }

        public SeoMetaData GetProductSeoData(ProductDetailViewModel product)
        {
            var siteName = _configuration.GetValue<string>("AppSettings:SiteName", "E-Commerce Store");
            var siteUrl = _configuration.GetValue<string>("AppSettings:SiteUrl", "https://yourdomain.com");

            return new SeoMetaData
            {
                Title = $"{product.Name} - {siteName}",
                Description = !string.IsNullOrEmpty(product.MetaDescription) 
                    ? product.MetaDescription 
                    : product.ShortDescription,
                Keywords = product.Keywords ?? $"{product.Name}, {product.CategoryName}, buy online",
                CanonicalUrl = $"{siteUrl}/product/{product.Slug}",
                OgTitle = product.Name,
                OgDescription = product.ShortDescription,
                OgImage = $"{siteUrl}{product.Images.FirstOrDefault()?.ImageUrl ?? "/images/no-image.jpg"}",
                OgType = "product"
            };
        }

        public SeoMetaData GetCategorySeoData(CategoryWithProductsViewModel category)
        {
            var siteName = _configuration.GetValue<string>("AppSettings:SiteName", "E-Commerce Store");
            var siteUrl = _configuration.GetValue<string>("AppSettings:SiteUrl", "https://yourdomain.com");

            return new SeoMetaData
            {
                Title = $"{category.Name} - Shop Online at {siteName}",
                Description = !string.IsNullOrEmpty(category.Description) 
                    ? category.Description 
                    : $"Browse our collection of {category.Name}. Find the best deals and shop online at {siteName}.",
                Keywords = $"{category.Name}, buy {category.Name} online, {category.Name} deals",
                CanonicalUrl = $"{siteUrl}/category/{category.Slug}",
                OgTitle = category.Name,
                OgDescription = category.Description ?? $"Browse our collection of {category.Name}",
                OgImage = $"{siteUrl}{category.ImageUrl ?? "/images/no-image.jpg"}",
                OgType = "website"
            };
        }

        public string GenerateStructuredDataProduct(ProductDetailViewModel product)
        {
            var siteUrl = _configuration.GetValue<string>("AppSettings:SiteUrl", "https://yourdomain.com");
            
            var structuredData = new
            {
                @context = "https://schema.org",
                @type = "Product",
                name = product.Name,
                image = product.Images.Select(i => $"{siteUrl}{i.ImageUrl}").ToArray(),
                description = product.ShortDescription,
                sku = product.Id.ToString(),
                brand = new
                {
                    @type = "Brand",
                    name = "Generic"
                },
                offers = new
                {
                    @type = "Offer",
                    url = $"{siteUrl}/product/{product.Slug}",
                    priceCurrency = "USD",
                    price = product.Price.ToString("F2"),
                    availability = product.IsOutOfStock 
                        ? "https://schema.org/OutOfStock" 
                        : "https://schema.org/InStock",
                    priceValidUntil = DateTime.UtcNow.AddYears(1).ToString("yyyy-MM-dd")
                }
            };

            if (product.CompareAtPrice.HasValue && product.CompareAtPrice > product.Price)
            {
                var offers = structuredData.offers as System.Dynamic.ExpandoObject;
                // Add price specification for sale price
            }

            return JsonSerializer.Serialize(structuredData, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                WriteIndented = true
            });
        }

        public string GenerateStructuredDataOrganization()
        {
            var siteName = _configuration.GetValue<string>("AppSettings:SiteName", "E-Commerce Store");
            var siteUrl = _configuration.GetValue<string>("AppSettings:SiteUrl", "https://yourdomain.com");

            var structuredData = new
            {
                @context = "https://schema.org",
                @type = "Organization",
                name = siteName,
                url = siteUrl,
                logo = $"{siteUrl}/images/logo.png",
                sameAs = new[]
                {
                    "https://www.facebook.com/yourpage",
                    "https://www.twitter.com/yourhandle",
                    "https://www.instagram.com/yourhandle"
                },
                contactPoint = new[]
                {
                    new
                    {
                        @type = "ContactPoint",
                        telephone = "+1-800-123-4567",
                        contactType = "customer service",
                        availableLanguage = new[] { "English" }
                    }
                }
            };

            return JsonSerializer.Serialize(structuredData, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                WriteIndented = true
            });
        }

        public string GenerateBreadcrumbJsonLd(List<BreadcrumbItem> breadcrumbs)
        {
            var siteUrl = _configuration.GetValue<string>("AppSettings:SiteUrl", "https://yourdomain.com");

            var itemListElement = breadcrumbs.Select((item, index) => new
            {
                @type = "ListItem",
                position = index + 1,
                name = item.Name,
                item = string.IsNullOrEmpty(item.Url) ? null : $"{siteUrl}{item.Url}"
            }).ToArray();

            var structuredData = new
            {
                @context = "https://schema.org",
                @type = "BreadcrumbList",
                itemListElement
            };

            return JsonSerializer.Serialize(structuredData, new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                WriteIndented = true
            });
        }
    }
}
