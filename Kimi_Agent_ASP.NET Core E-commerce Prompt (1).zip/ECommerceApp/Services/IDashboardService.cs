using ECommerceApp.Models.ViewModels;

namespace ECommerceApp.Services
{
    public interface IDashboardService
    {
        Task<DashboardViewModel> GetDashboardDataAsync();
        Task<List<RevenueChartDataViewModel>> GetRevenueChartDataAsync(int days = 30);
        Task<List<TopProductViewModel>> GetTopProductsAsync(int count = 10);
    }
}
