using ECommerceApp.Models.ViewModels;

namespace ECommerceApp.Services
{
    public interface IProductService
    {
        Task<IEnumerable<ProductListViewModel>> GetAllProductsAsync();
        Task<IEnumerable<ProductListViewModel>> GetActiveProductsAsync();
        Task<IEnumerable<ProductListViewModel>> GetFeaturedProductsAsync(int count);
        Task<IEnumerable<ProductListViewModel>> GetLatestProductsAsync(int count);
        Task<ProductViewModel?> GetProductByIdAsync(int id);
        Task<ProductDetailViewModel?> GetProductBySlugAsync(string slug);
        Task<IEnumerable<ProductListViewModel>> GetProductsByCategoryAsync(int categoryId);
        Task<IEnumerable<ProductListViewModel>> SearchProductsAsync(string searchTerm);
        Task<ProductViewModel> CreateProductAsync(ProductViewModel model);
        Task<ProductViewModel?> UpdateProductAsync(ProductViewModel model);
        Task<bool> DeleteProductAsync(int id);
        Task<bool> ToggleActiveAsync(int id);
        Task<bool> ToggleFeaturedAsync(int id);
        Task<bool> ProductExistsAsync(int id);
        Task<string> GenerateSlugAsync(string name, int? excludeId = null);
        Task<(IEnumerable<ProductListViewModel> Products, int TotalCount)> GetPagedProductsAsync(
            int page, int pageSize, int? categoryId = null, string? searchTerm = null, 
            bool? isActive = null, bool? isFeatured = null);
    }
}
