using CsvHelper;
using CsvHelper.Configuration;
using ECommerceApp.Models.ViewModels;
using System.Globalization;
using System.Text;

namespace ECommerceApp.Services
{
    public class CsvService : ICsvService
    {
        private readonly ICategoryService _categoryService;
        private readonly IProductService _productService;

        public CsvService(ICategoryService categoryService, IProductService productService)
        {
            _categoryService = categoryService;
            _productService = productService;
        }

        public async Task<(List<ProductCsvModel> Products, List<string> Errors)> ImportProductsAsync(Stream csvStream)
        {
            var products = new List<ProductCsvModel>();
            var errors = new List<string>();
            var categories = await _categoryService.GetAllCategoriesAsync();
            var categoryDict = categories.ToDictionary(c => c.Name.ToLower(), c => c.Id);

            using var reader = new StreamReader(csvStream, Encoding.UTF8);
            using var csv = new CsvReader(reader, new CsvConfiguration(CultureInfo.InvariantCulture)
            {
                HeaderValidated = null,
                MissingFieldFound = null
            });

            var records = csv.GetRecords<ProductCsvModel>().ToList();
            var rowNumber = 1;

            foreach (var record in records)
            {
                rowNumber++;
                var rowErrors = new List<string>();

                if (string.IsNullOrWhiteSpace(record.CategoryName))
                    rowErrors.Add($"Row {rowNumber}: CategoryName is required");
                else if (!categoryDict.ContainsKey(record.CategoryName.ToLower()))
                    rowErrors.Add($"Row {rowNumber}: Category '{record.CategoryName}' not found");

                if (string.IsNullOrWhiteSpace(record.ProductName))
                    rowErrors.Add($"Row {rowNumber}: ProductName is required");

                if (string.IsNullOrWhiteSpace(record.ShortDescription))
                    rowErrors.Add($"Row {rowNumber}: ShortDescription is required");

                if (string.IsNullOrWhiteSpace(record.FullDescription))
                    rowErrors.Add($"Row {rowNumber}: FullDescription is required");

                if (record.Price <= 0)
                    rowErrors.Add($"Row {rowNumber}: Price must be greater than 0");

                if (record.Stock < 0)
                    rowErrors.Add($"Row {rowNumber}: Stock cannot be negative");

                if (rowErrors.Any())
                {
                    errors.AddRange(rowErrors);
                }
                else
                {
                    products.Add(record);
                }
            }

            return (products, errors);
        }

        public async Task<byte[]> ExportProductsAsync(IEnumerable<ProductListViewModel> products)
        {
            var csvModels = products.Select(p => new ProductCsvModel
            {
                CategoryName = p.CategoryName,
                ProductName = p.Name,
                ShortDescription = p.ShortDescription,
                FullDescription = string.Empty,
                Price = p.Price,
                CompareAtPrice = p.CompareAtPrice,
                Stock = 0,
                ImageUrl = p.PrimaryImageUrl,
                IsActive = true,
                IsFeatured = p.IsFeatured
            });

            using var memoryStream = new MemoryStream();
            using var writer = new StreamWriter(memoryStream, Encoding.UTF8);
            using var csv = new CsvWriter(writer, new CsvConfiguration(CultureInfo.InvariantCulture));

            csv.WriteRecords(csvModels);
            writer.Flush();

            return memoryStream.ToArray();
        }

        public async Task<byte[]> GetSampleCsvAsync()
        {
            var sampleData = new List<ProductCsvModel>
            {
                new ProductCsvModel
                {
                    CategoryName = "Electronics",
                    ProductName = "Sample Product 1",
                    ShortDescription = "Short description of product 1",
                    FullDescription = "Full detailed description of product 1",
                    Price = 99.99m,
                    CompareAtPrice = 129.99m,
                    Stock = 100,
                    ImageUrl = "https://example.com/image1.jpg",
                    IsActive = true,
                    IsFeatured = false
                },
                new ProductCsvModel
                {
                    CategoryName = "Clothing",
                    ProductName = "Sample Product 2",
                    ShortDescription = "Short description of product 2",
                    FullDescription = "Full detailed description of product 2",
                    Price = 49.99m,
                    CompareAtPrice = null,
                    Stock = 50,
                    ImageUrl = "https://example.com/image2.jpg",
                    IsActive = true,
                    IsFeatured = true
                }
            };

            using var memoryStream = new MemoryStream();
            using var writer = new StreamWriter(memoryStream, Encoding.UTF8);
            using var csv = new CsvWriter(writer, new CsvConfiguration(CultureInfo.InvariantCulture));

            csv.WriteRecords(sampleData);
            writer.Flush();

            return memoryStream.ToArray();
        }
    }
}
