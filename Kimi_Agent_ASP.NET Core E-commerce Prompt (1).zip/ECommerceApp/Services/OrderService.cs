using ECommerceApp.Models;
using ECommerceApp.Models.ViewModels;
using ECommerceApp.Repositories;

namespace ECommerceApp.Services
{
    public class OrderService : IOrderService
    {
        private readonly IUnitOfWork _unitOfWork;

        public OrderService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<OrderViewModel?> GetOrderByIdAsync(int id)
        {
            var order = await _unitOfWork.Orders.GetByIdAsync(id, o => o.OrderItems);
            return order != null ? MapToViewModel(order) : null;
        }

        public async Task<OrderViewModel?> GetOrderByNumberAsync(string orderNumber)
        {
            var order = await _unitOfWork.Orders.GetByOrderNumberWithDetailsAsync(orderNumber);
            return order != null ? MapToViewModel(order) : null;
        }

        public async Task<IEnumerable<OrderViewModel>> GetOrdersByUserIdAsync(string userId)
        {
            var orders = await _unitOfWork.Orders.GetByUserIdAsync(userId);
            return orders.Select(MapToViewModel);
        }

        public async Task<(IEnumerable<OrderViewModel> Orders, int TotalCount)> GetPagedOrdersAsync(
            int page, int pageSize, OrderStatus? status = null, 
            DateTime? fromDate = null, DateTime? toDate = null, string? searchTerm = null)
        {
            var (orders, totalCount) = await _unitOfWork.Orders.GetPagedOrdersAsync(
                page, pageSize, status, fromDate, toDate, searchTerm);
            
            return (orders.Select(MapToViewModel), totalCount);
        }

        public async Task<OrderConfirmationViewModel> CreateOrderAsync(CheckoutViewModel model, ShoppingCart cart)
        {
            var orderNumber = await GenerateOrderNumberAsync();
            
            var subTotal = cart.TotalPrice;
            var shippingCost = model.ShippingCost;
            var taxAmount = subTotal * (model.TaxRate / 100);
            var totalAmount = subTotal + shippingCost + taxAmount;

            var order = new Order
            {
                OrderNumber = orderNumber,
                CustomerName = model.CustomerName,
                CustomerEmail = model.CustomerEmail,
                CustomerPhone = model.CustomerPhone,
                ShippingAddress = model.ShippingAddress,
                ShippingCity = model.ShippingCity,
                ShippingPostalCode = model.ShippingPostalCode,
                ShippingCountry = model.ShippingCountry,
                OrderNotes = model.OrderNotes,
                SubTotal = subTotal,
                ShippingCost = shippingCost,
                TaxAmount = taxAmount,
                DiscountAmount = 0,
                TotalAmount = totalAmount,
                OrderStatus = OrderStatus.Pending,
                PaymentStatus = model.PaymentMethod == PaymentMethod.CashOnDelivery 
                    ? PaymentStatus.Pending 
                    : PaymentStatus.Pending,
                PaymentMethod = model.PaymentMethod,
                CreatedAt = DateTime.UtcNow
            };

            await _unitOfWork.BeginTransactionAsync();

            try
            {
                await _unitOfWork.Orders.AddAsync(order);
                await _unitOfWork.SaveChangesAsync();

                foreach (var item in cart.Items)
                {
                    var product = await _unitOfWork.Products.GetByIdAsync(item.ProductId);
                    if (product != null)
                    {
                        var orderItem = new OrderItem
                        {
                            OrderId = order.Id,
                            ProductId = item.ProductId,
                            ProductName = item.ProductName,
                            ProductImageUrl = item.ProductImageUrl,
                            UnitPrice = item.UnitPrice,
                            Quantity = item.Quantity,
                            Discount = 0,
                            CreatedAt = DateTime.UtcNow
                        };
                        await _unitOfWork.OrderItems.AddAsync(orderItem);

                        // Update stock
                        product.StockQuantity -= item.Quantity;
                        _unitOfWork.Products.Update(product);
                    }
                }

                await _unitOfWork.SaveChangesAsync();
                await _unitOfWork.CommitTransactionAsync();

                return new OrderConfirmationViewModel
                {
                    OrderNumber = order.OrderNumber,
                    TotalAmount = order.TotalAmount,
                    CustomerEmail = order.CustomerEmail,
                    CreatedAt = order.CreatedAt
                };
            }
            catch
            {
                await _unitOfWork.RollbackTransactionAsync();
                throw;
            }
        }

        public async Task<bool> UpdateOrderStatusAsync(int orderId, OrderStatus status)
        {
            var order = await _unitOfWork.Orders.GetByIdAsync(orderId);
            if (order == null) return false;

            order.OrderStatus = status;
            order.UpdatedAt = DateTime.UtcNow;

            switch (status)
            {
                case OrderStatus.Processing:
                    break;
                case OrderStatus.Shipped:
                    order.ShippedAt = DateTime.UtcNow;
                    break;
                case OrderStatus.Completed:
                    order.DeliveredAt = DateTime.UtcNow;
                    if (order.PaymentMethod == PaymentMethod.CashOnDelivery)
                    {
                        order.PaymentStatus = PaymentStatus.Paid;
                        order.PaidAt = DateTime.UtcNow;
                    }
                    break;
                case OrderStatus.Cancelled:
                    // Restore stock
                    var orderItems = await _unitOfWork.OrderItems.GetByOrderIdAsync(orderId);
                    foreach (var item in orderItems)
                    {
                        var product = await _unitOfWork.Products.GetByIdAsync(item.ProductId);
                        if (product != null)
                        {
                            product.StockQuantity += item.Quantity;
                            _unitOfWork.Products.Update(product);
                        }
                    }
                    break;
            }

            _unitOfWork.Orders.Update(order);
            await _unitOfWork.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UpdatePaymentStatusAsync(int orderId, PaymentStatus status)
        {
            var order = await _unitOfWork.Orders.GetByIdAsync(orderId);
            if (order == null) return false;

            order.PaymentStatus = status;
            order.UpdatedAt = DateTime.UtcNow;

            if (status == PaymentStatus.Paid)
            {
                order.PaidAt = DateTime.UtcNow;
            }

            _unitOfWork.Orders.Update(order);
            await _unitOfWork.SaveChangesAsync();
            return true;
        }

        public async Task<bool> CancelOrderAsync(int orderId)
        {
            return await UpdateOrderStatusAsync(orderId, OrderStatus.Cancelled);
        }

        public async Task<IEnumerable<OrderViewModel>> GetRecentOrdersAsync(int count)
        {
            var orders = await _unitOfWork.Orders.GetRecentOrdersAsync(count);
            return orders.Select(MapToViewModel);
        }

        public async Task<byte[]> ExportOrdersToCsvAsync(OrderFilterViewModel filter)
        {
            var (orders, _) = await _unitOfWork.Orders.GetPagedOrdersAsync(
                1, int.MaxValue, filter.Status, filter.FromDate, filter.ToDate, filter.SearchTerm);

            var csvModels = orders.Select(o => new OrderCsvExportModel
            {
                OrderNumber = o.OrderNumber,
                OrderDate = o.CreatedAt,
                CustomerName = o.CustomerName,
                CustomerEmail = o.CustomerEmail,
                CustomerPhone = o.CustomerPhone,
                ShippingAddress = o.ShippingAddress,
                OrderStatus = o.OrderStatus.ToString(),
                PaymentStatus = o.PaymentStatus.ToString(),
                PaymentMethod = o.PaymentMethod.ToString(),
                SubTotal = o.SubTotal,
                ShippingCost = o.ShippingCost,
                TaxAmount = o.TaxAmount,
                TotalAmount = o.TotalAmount,
                TotalItems = o.TotalItems
            });

            using var memoryStream = new MemoryStream();
            using var writer = new StreamWriter(memoryStream);
            using var csv = new CsvHelper.CsvWriter(writer, System.Globalization.CultureInfo.InvariantCulture);
            
            csv.WriteRecords(csvModels);
            writer.Flush();
            
            return memoryStream.ToArray();
        }

        public async Task<string> GenerateOrderNumberAsync()
        {
            var datePrefix = DateTime.UtcNow.ToString("yyyyMMdd");
            var random = new Random();
            string orderNumber;
            
            do
            {
                var randomSuffix = random.Next(1000, 9999);
                orderNumber = $"ORD-{datePrefix}-{randomSuffix}";
            } while (await _unitOfWork.Orders.Query().AnyAsync(o => o.OrderNumber == orderNumber));

            return orderNumber;
        }

        private OrderViewModel MapToViewModel(Order order)
        {
            return new OrderViewModel
            {
                Id = order.Id,
                OrderNumber = order.OrderNumber,
                UserId = order.UserId,
                CustomerName = order.CustomerName,
                CustomerEmail = order.CustomerEmail,
                CustomerPhone = order.CustomerPhone,
                ShippingAddress = order.ShippingAddress,
                ShippingCity = order.ShippingCity,
                ShippingPostalCode = order.ShippingPostalCode,
                ShippingCountry = order.ShippingCountry,
                OrderNotes = order.OrderNotes,
                SubTotal = order.SubTotal,
                ShippingCost = order.ShippingCost,
                TaxAmount = order.TaxAmount,
                DiscountAmount = order.DiscountAmount,
                TotalAmount = order.TotalAmount,
                OrderStatus = order.OrderStatus,
                PaymentStatus = order.PaymentStatus,
                PaymentMethod = order.PaymentMethod,
                PaidAt = order.PaidAt,
                ShippedAt = order.ShippedAt,
                DeliveredAt = order.DeliveredAt,
                CreatedAt = order.CreatedAt,
                TotalItems = order.TotalItems,
                OrderItems = order.OrderItems?.Select(oi => new OrderItemViewModel
                {
                    Id = oi.Id,
                    ProductId = oi.ProductId,
                    ProductName = oi.ProductName,
                    ProductImageUrl = oi.ProductImageUrl,
                    UnitPrice = oi.UnitPrice,
                    Quantity = oi.Quantity,
                    Discount = oi.Discount,
                    TotalPrice = oi.TotalPrice
                }).ToList() ?? new List<OrderItemViewModel>()
            };
        }
    }
}
