using ECommerceApp.Models;
using ECommerceApp.Models.ViewModels;
using ECommerceApp.Repositories;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace ECommerceApp.Services
{
    public class DashboardService : IDashboardService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly UserManager<ApplicationUser> _userManager;

        public DashboardService(IUnitOfWork unitOfWork, UserManager<ApplicationUser> userManager)
        {
            _unitOfWork = unitOfWork;
            _userManager = userManager;
        }

        public async Task<DashboardViewModel> GetDashboardDataAsync()
        {
            var totalProducts = await _unitOfWork.Products.CountAsync();
            var totalCategories = await _unitOfWork.Categories.CountAsync(c => c.IsActive);
            var totalOrders = await _unitOfWork.Orders.GetTotalOrdersCountAsync();
            var pendingOrders = await _unitOfWork.Orders.GetOrdersCountByStatusAsync(OrderStatus.Pending);
            var processingOrders = await _unitOfWork.Orders.GetOrdersCountByStatusAsync(OrderStatus.Processing);
            var completedOrders = await _unitOfWork.Orders.GetOrdersCountByStatusAsync(OrderStatus.Completed);
            var totalRevenue = await _unitOfWork.Orders.GetTotalRevenueAsync();
            var todayRevenue = await _unitOfWork.Orders.GetTodayRevenueAsync();
            var monthRevenue = await _unitOfWork.Orders.GetMonthRevenueAsync();
            var lowStockProducts = (await _unitOfWork.Products.GetLowStockProductsAsync()).Count();
            var outOfStockProducts = (await _unitOfWork.Products.GetOutOfStockProductsAsync()).Count();
            var totalCustomers = await _userManager.Users.CountAsync();

            var recentOrders = await _unitOfWork.Orders.GetRecentOrdersAsync(10);
            var topProducts = await GetTopProductsAsync(5);
            var revenueChartData = await GetRevenueChartDataAsync(7);

            return new DashboardViewModel
            {
                TotalProducts = totalProducts,
                TotalCategories = totalCategories,
                TotalOrders = totalOrders,
                PendingOrders = pendingOrders,
                ProcessingOrders = processingOrders,
                CompletedOrders = completedOrders,
                TotalRevenue = totalRevenue,
                TodayRevenue = todayRevenue,
                MonthRevenue = monthRevenue,
                LowStockProducts = lowStockProducts,
                OutOfStockProducts = outOfStockProducts,
                TotalCustomers = totalCustomers,
                RecentOrders = recentOrders.Select(o => new RecentOrderViewModel
                {
                    Id = o.Id,
                    OrderNumber = o.OrderNumber,
                    CustomerName = o.CustomerName,
                    TotalAmount = o.TotalAmount,
                    OrderStatus = o.OrderStatus,
                    CreatedAt = o.CreatedAt
                }).ToList(),
                TopProducts = topProducts,
                RevenueChartData = revenueChartData
            };
        }

        public async Task<List<RevenueChartDataViewModel>> GetRevenueChartDataAsync(int days = 30)
        {
            var endDate = DateTime.UtcNow.Date;
            var startDate = endDate.AddDays(-days + 1);
            
            var chartData = new List<RevenueChartDataViewModel>();

            for (var date = startDate; date <= endDate; date = date.AddDays(1))
            {
                var dayStart = date;
                var dayEnd = date.AddDays(1).AddTicks(-1);

                var orders = await _unitOfWork.Orders.FindAsync(o => 
                    o.CreatedAt >= dayStart && 
                    o.CreatedAt <= dayEnd &&
                    o.OrderStatus != OrderStatus.Cancelled);

                var revenue = orders.Where(o => o.PaymentStatus == PaymentStatus.Paid).Sum(o => o.TotalAmount);
                var orderCount = orders.Count();

                chartData.Add(new RevenueChartDataViewModel
                {
                    Label = date.ToString("MMM dd"),
                    Revenue = revenue,
                    OrderCount = orderCount
                });
            }

            return chartData;
        }

        public async Task<List<TopProductViewModel>> GetTopProductsAsync(int count = 10)
        {
            var topProducts = await _unitOfWork.OrderItems.Query()
                .AsNoTracking()
                .GroupBy(oi => new { oi.ProductId, oi.ProductName, oi.ProductImageUrl })
                .Select(g => new TopProductViewModel
                {
                    Id = g.Key.ProductId,
                    Name = g.Key.ProductName,
                    ImageUrl = g.Key.ProductImageUrl,
                    TotalSold = g.Sum(oi => oi.Quantity),
                    TotalRevenue = g.Sum(oi => oi.TotalPrice)
                })
                .OrderByDescending(p => p.TotalSold)
                .Take(count)
                .ToListAsync();

            return topProducts;
        }
    }
}
