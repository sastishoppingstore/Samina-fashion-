using ECommerceApp.Models.ViewModels;

namespace ECommerceApp.Services
{
    public interface ICsvService
    {
        Task<(List<ProductCsvModel> Products, List<string> Errors)> ImportProductsAsync(Stream csvStream);
        Task<byte[]> ExportProductsAsync(IEnumerable<ProductListViewModel> products);
        Task<byte[]> GetSampleCsvAsync();
    }
}
