using ECommerceApp.Models;
using ECommerceApp.Models.ViewModels;

namespace ECommerceApp.Services
{
    public interface ICategoryService
    {
        Task<IEnumerable<CategoryViewModel>> GetAllCategoriesAsync();
        Task<IEnumerable<CategoryViewModel>> GetActiveCategoriesAsync();
        Task<IEnumerable<CategoryDropdownViewModel>> GetCategoriesForDropdownAsync();
        Task<CategoryViewModel?> GetCategoryByIdAsync(int id);
        Task<CategoryViewModel?> GetCategoryBySlugAsync(string slug);
        Task<CategoryWithProductsViewModel?> GetCategoryWithProductsAsync(string slug);
        Task<IEnumerable<CategorySectionViewModel>> GetHomepageCategorySectionsAsync();
        Task<CategoryViewModel> CreateCategoryAsync(CategoryViewModel model);
        Task<CategoryViewModel?> UpdateCategoryAsync(CategoryViewModel model);
        Task<bool> DeleteCategoryAsync(int id);
        Task<bool> CategoryExistsAsync(int id);
        Task<string> GenerateSlugAsync(string name, int? excludeId = null);
    }
}
