using ECommerceApp.Models;
using ECommerceApp.Models.ViewModels;
using ECommerceApp.Repositories;
using Microsoft.AspNetCore.Http;
using System.Text.Json;

namespace ECommerceApp.Services
{
    public class ShoppingCartService : IShoppingCartService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private const string CartSessionKey = "ShoppingCart";

        public ShoppingCartService(
            IUnitOfWork unitOfWork,
            IHttpContextAccessor httpContextAccessor)
        {
            _unitOfWork = unitOfWork;
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task<ShoppingCart> GetCartAsync(string sessionId)
        {
            var session = _httpContextAccessor.HttpContext?.Session;
            if (session == null) return new ShoppingCart { SessionId = sessionId };

            var cartJson = session.GetString($"{CartSessionKey}_{sessionId}");
            if (string.IsNullOrEmpty(cartJson))
            {
                return new ShoppingCart { SessionId = sessionId };
            }

            return JsonSerializer.Deserialize<ShoppingCart>(cartJson) ?? new ShoppingCart { SessionId = sessionId };
        }

        public async Task AddToCartAsync(string sessionId, int productId, int quantity)
        {
            var cart = await GetCartAsync(sessionId);
            var product = await _unitOfWork.Products.GetByIdAsync(productId);

            if (product == null || !product.IsActive)
                throw new InvalidOperationException("Product not found or inactive.");

            if (product.StockQuantity < quantity)
                throw new InvalidOperationException("Insufficient stock.");

            var existingItem = cart.Items.FirstOrDefault(i => i.ProductId == productId);
            if (existingItem != null)
            {
                var newQuantity = existingItem.Quantity + quantity;
                if (newQuantity > product.StockQuantity)
                    throw new InvalidOperationException("Insufficient stock.");
                
                existingItem.Quantity = newQuantity;
            }
            else
            {
                cart.Items.Add(new CartItem
                {
                    ProductId = product.Id,
                    ProductName = product.Name,
                    ProductImageUrl = product.PrimaryImageUrl,
                    UnitPrice = product.Price,
                    Quantity = quantity,
                    MaxStock = product.StockQuantity
                });
            }

            await SaveCartAsync(sessionId, cart);
        }

        public async Task RemoveFromCartAsync(string sessionId, int productId)
        {
            var cart = await GetCartAsync(sessionId);
            cart.RemoveItem(productId);
            await SaveCartAsync(sessionId, cart);
        }

        public async Task UpdateQuantityAsync(string sessionId, int productId, int quantity)
        {
            var cart = await GetCartAsync(sessionId);
            var product = await _unitOfWork.Products.GetByIdAsync(productId);

            if (product == null)
                throw new InvalidOperationException("Product not found.");

            if (quantity > product.StockQuantity)
                throw new InvalidOperationException("Insufficient stock.");

            cart.UpdateQuantity(productId, quantity);
            await SaveCartAsync(sessionId, cart);
        }

        public async Task ClearCartAsync(string sessionId)
        {
            var cart = new ShoppingCart { SessionId = sessionId };
            await SaveCartAsync(sessionId, cart);
        }

        public async Task<CartViewModel> GetCartViewModelAsync(string sessionId)
        {
            var cart = await GetCartAsync(sessionId);
            
            return new CartViewModel
            {
                Items = cart.Items.Select(i => new CartItemViewModel
                {
                    ProductId = i.ProductId,
                    ProductName = i.ProductName,
                    ProductImageUrl = i.ProductImageUrl,
                    UnitPrice = i.UnitPrice,
                    Quantity = i.Quantity,
                    MaxStock = i.MaxStock,
                    TotalPrice = i.TotalPrice
                }).ToList(),
                TotalItems = cart.TotalItems,
                SubTotal = cart.TotalPrice,
                ShippingCost = cart.TotalPrice >= 50 ? 0 : 5.99m,
                TaxAmount = cart.TotalPrice * 0.08m,
                Total = cart.TotalPrice + (cart.TotalPrice >= 50 ? 0 : 5.99m) + (cart.TotalPrice * 0.08m)
            };
        }

        public async Task<int> GetCartItemCountAsync(string sessionId)
        {
            var cart = await GetCartAsync(sessionId);
            return cart.TotalItems;
        }

        private async Task SaveCartAsync(string sessionId, ShoppingCart cart)
        {
            var session = _httpContextAccessor.HttpContext?.Session;
            if (session == null) return;

            var cartJson = JsonSerializer.Serialize(cart);
            session.SetString($"{CartSessionKey}_{sessionId}", cartJson);
        }
    }
}
