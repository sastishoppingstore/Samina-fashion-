using ECommerceApp.Models.ViewModels;
using ECommerceApp.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ECommerceApp.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin,Manager")]
    public class ProductsController : Controller
    {
        private readonly IProductService _productService;
        private readonly ICategoryService _categoryService;
        private readonly ICsvService _csvService;

        public ProductsController(
            IProductService productService,
            ICategoryService categoryService,
            ICsvService csvService)
        {
            _productService = productService;
            _categoryService = categoryService;
            _csvService = csvService;
        }

        public async Task<IActionResult> Index(int page = 1, int? categoryId = null, string? search = null)
        {
            const int pageSize = 20;
            var (products, totalCount) = await _productService.GetPagedProductsAsync(
                page, pageSize, categoryId, search);

            ViewBag.CurrentPage = page;
            ViewBag.TotalPages = (int)Math.Ceiling(totalCount / (double)pageSize);
            ViewBag.CategoryId = categoryId;
            ViewBag.Search = search;
            ViewBag.Categories = await _categoryService.GetCategoriesForDropdownAsync();

            return View(products);
        }

        public async Task<IActionResult> Create()
        {
            var model = new ProductViewModel
            {
                Categories = (await _categoryService.GetCategoriesForDropdownAsync()).ToList()
            };
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ProductViewModel model)
        {
            if (!ModelState.IsValid)
            {
                model.Categories = (await _categoryService.GetCategoriesForDropdownAsync()).ToList();
                return View(model);
            }

            try
            {
                await _productService.CreateProductAsync(model);
                TempData["Success"] = "Product created successfully.";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                model.Categories = (await _categoryService.GetCategoriesForDropdownAsync()).ToList();
                return View(model);
            }
        }

        public async Task<IActionResult> Edit(int id)
        {
            var product = await _productService.GetProductByIdAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            product.Categories = (await _categoryService.GetCategoriesForDropdownAsync()).ToList();
            return View(product);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(ProductViewModel model)
        {
            if (!ModelState.IsValid)
            {
                model.Categories = (await _categoryService.GetCategoriesForDropdownAsync()).ToList();
                return View(model);
            }

            try
            {
                var result = await _productService.UpdateProductAsync(model);
                if (result == null)
                {
                    return NotFound();
                }

                TempData["Success"] = "Product updated successfully.";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                model.Categories = (await _categoryService.GetCategoriesForDropdownAsync()).ToList();
                return View(model);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var result = await _productService.DeleteProductAsync(id);
            if (!result)
            {
                return NotFound();
            }

            TempData["Success"] = "Product deleted successfully.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public async Task<IActionResult> ToggleActive(int id)
        {
            var result = await _productService.ToggleActiveAsync(id);
            return Json(new { success = result });
        }

        [HttpPost]
        public async Task<IActionResult> ToggleFeatured(int id)
        {
            var result = await _productService.ToggleFeaturedAsync(id);
            return Json(new { success = result });
        }

        public async Task<IActionResult> Import()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Import(IFormFile csvFile)
        {
            if (csvFile == null || csvFile.Length == 0)
            {
                ModelState.AddModelError("", "Please select a CSV file.");
                return View();
            }

            try
            {
                using var stream = csvFile.OpenReadStream();
                var (products, errors) = await _csvService.ImportProductsAsync(stream);

                if (errors.Any())
                {
                    ViewBag.Errors = errors;
                    ViewBag.ImportedCount = 0;
                    return View();
                }

                // Import products
                var categories = await _categoryService.GetAllCategoriesAsync();
                var categoryDict = categories.ToDictionary(c => c.Name.ToLower(), c => c.Id);

                foreach (var csvProduct in products)
                {
                    var product = new ProductViewModel
                    {
                        Name = csvProduct.ProductName,
                        ShortDescription = csvProduct.ShortDescription,
                        FullDescription = csvProduct.FullDescription,
                        Price = csvProduct.Price,
                        CompareAtPrice = csvProduct.CompareAtPrice,
                        StockQuantity = csvProduct.Stock,
                        CategoryId = categoryDict[csvProduct.CategoryName.ToLower()],
                        IsActive = csvProduct.IsActive,
                        IsFeatured = csvProduct.IsFeatured
                    };

                    await _productService.CreateProductAsync(product);
                }

                TempData["Success"] = $"{products.Count} products imported successfully.";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View();
            }
        }

        public async Task<IActionResult> Export()
        {
            var products = await _productService.GetAllProductsAsync();
            var csvBytes = await _csvService.ExportProductsAsync(products);
            
            return File(csvBytes, "text/csv", $"products_export_{DateTime.UtcNow:yyyyMMdd}.csv");
        }

        public async Task<IActionResult> DownloadSampleCsv()
        {
            var csvBytes = await _csvService.GetSampleCsvAsync();
            return File(csvBytes, "text/csv", "products_sample.csv");
        }

        public async Task<IActionResult> LowStock()
        {
            var products = await _productService.GetAllProductsAsync();
            var lowStockProducts = products.Where(p => p.IsLowStock && !p.IsOutOfStock);
            return View(lowStockProducts);
        }

        public async Task<IActionResult> OutOfStock()
        {
            var products = await _productService.GetAllProductsAsync();
            var outOfStockProducts = products.Where(p => p.IsOutOfStock);
            return View(outOfStockProducts);
        }
    }
}
