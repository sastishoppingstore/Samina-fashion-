using ECommerceApp.Models.ViewModels;
using ECommerceApp.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ECommerceApp.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin,Manager")]
    public class CategoriesController : Controller
    {
        private readonly ICategoryService _categoryService;

        public CategoriesController(ICategoryService categoryService)
        {
            _categoryService = categoryService;
        }

        public async Task<IActionResult> Index()
        {
            var categories = await _categoryService.GetAllCategoriesAsync();
            return View(categories);
        }

        public async Task<IActionResult> Create()
        {
            var model = new CategoryViewModel
            {
                ParentCategories = (await _categoryService.GetCategoriesForDropdownAsync()).ToList()
            };
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CategoryViewModel model)
        {
            if (!ModelState.IsValid)
            {
                model.ParentCategories = (await _categoryService.GetCategoriesForDropdownAsync()).ToList();
                return View(model);
            }

            try
            {
                await _categoryService.CreateCategoryAsync(model);
                TempData["Success"] = "Category created successfully.";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                model.ParentCategories = (await _categoryService.GetCategoriesForDropdownAsync()).ToList();
                return View(model);
            }
        }

        public async Task<IActionResult> Edit(int id)
        {
            var category = await _categoryService.GetCategoryByIdAsync(id);
            if (category == null)
            {
                return NotFound();
            }

            var allCategories = await _categoryService.GetCategoriesForDropdownAsync();
            category.ParentCategories = allCategories.Where(c => c.Id != id).ToList();

            return View(category);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(CategoryViewModel model)
        {
            if (!ModelState.IsValid)
            {
                var allCategories = await _categoryService.GetCategoriesForDropdownAsync();
                model.ParentCategories = allCategories.Where(c => c.Id != model.Id).ToList();
                return View(model);
            }

            try
            {
                var result = await _categoryService.UpdateCategoryAsync(model);
                if (result == null)
                {
                    return NotFound();
                }

                TempData["Success"] = "Category updated successfully.";
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                var allCategories = await _categoryService.GetCategoriesForDropdownAsync();
                model.ParentCategories = allCategories.Where(c => c.Id != model.Id).ToList();
                return View(model);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var result = await _categoryService.DeleteCategoryAsync(id);
                if (!result)
                {
                    return NotFound();
                }

                TempData["Success"] = "Category deleted successfully.";
            }
            catch (InvalidOperationException ex)
            {
                TempData["Error"] = ex.Message;
            }

            return RedirectToAction(nameof(Index));
        }
    }
}
