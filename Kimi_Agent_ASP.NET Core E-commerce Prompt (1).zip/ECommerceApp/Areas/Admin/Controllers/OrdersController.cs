using ECommerceApp.Models;
using ECommerceApp.Models.ViewModels;
using ECommerceApp.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ECommerceApp.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Admin,Manager")]
    public class OrdersController : Controller
    {
        private readonly IOrderService _orderService;

        public OrdersController(IOrderService orderService)
        {
            _orderService = orderService;
        }

        public async Task<IActionResult> Index(
            int page = 1, 
            OrderStatus? status = null, 
            DateTime? fromDate = null, 
            DateTime? toDate = null,
            string? search = null)
        {
            const int pageSize = 20;
            var (orders, totalCount) = await _orderService.GetPagedOrdersAsync(
                page, pageSize, status, fromDate, toDate, search);

            ViewBag.CurrentPage = page;
            ViewBag.TotalPages = (int)Math.Ceiling(totalCount / (double)pageSize);
            ViewBag.Status = status;
            ViewBag.FromDate = fromDate;
            ViewBag.ToDate = toDate;
            ViewBag.Search = search;

            return View(orders);
        }

        public async Task<IActionResult> Details(int id)
        {
            var order = await _orderService.GetOrderByIdAsync(id);
            if (order == null)
            {
                return NotFound();
            }

            return View(order);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateStatus(int id, OrderStatus status)
        {
            var result = await _orderService.UpdateOrderStatusAsync(id, status);
            if (!result)
            {
                return NotFound();
            }

            TempData["Success"] = "Order status updated successfully.";
            return RedirectToAction(nameof(Details), new { id });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdatePaymentStatus(int id, PaymentStatus status)
        {
            var result = await _orderService.UpdatePaymentStatusAsync(id, status);
            if (!result)
            {
                return NotFound();
            }

            TempData["Success"] = "Payment status updated successfully.";
            return RedirectToAction(nameof(Details), new { id });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Cancel(int id)
        {
            var result = await _orderService.CancelOrderAsync(id);
            if (!result)
            {
                return NotFound();
            }

            TempData["Success"] = "Order cancelled successfully.";
            return RedirectToAction(nameof(Details), new { id });
        }

        public async Task<IActionResult> Export(
            OrderStatus? status = null, 
            DateTime? fromDate = null, 
            DateTime? toDate = null,
            string? search = null)
        {
            var filter = new OrderFilterViewModel
            {
                Status = status,
                FromDate = fromDate,
                ToDate = toDate,
                SearchTerm = search
            };

            var csvBytes = await _orderService.ExportOrdersToCsvAsync(filter);
            return File(csvBytes, "text/csv", $"orders_export_{DateTime.UtcNow:yyyyMMdd}.csv");
        }

        public async Task<IActionResult> Pending()
        {
            const int pageSize = 20;
            var (orders, totalCount) = await _orderService.GetPagedOrdersAsync(1, pageSize, OrderStatus.Pending);
            
            ViewBag.CurrentPage = 1;
            ViewBag.TotalPages = (int)Math.Ceiling(totalCount / (double)pageSize);
            ViewBag.Status = OrderStatus.Pending;

            return View("Index", orders);
        }

        public async Task<IActionResult> Processing()
        {
            const int pageSize = 20;
            var (orders, totalCount) = await _orderService.GetPagedOrdersAsync(1, pageSize, OrderStatus.Processing);
            
            ViewBag.CurrentPage = 1;
            ViewBag.TotalPages = (int)Math.Ceiling(totalCount / (double)pageSize);
            ViewBag.Status = OrderStatus.Processing;

            return View("Index", orders);
        }

        public async Task<IActionResult> Completed()
        {
            const int pageSize = 20;
            var (orders, totalCount) = await _orderService.GetPagedOrdersAsync(1, pageSize, OrderStatus.Completed);
            
            ViewBag.CurrentPage = 1;
            ViewBag.TotalPages = (int)Math.Ceiling(totalCount / (double)pageSize);
            ViewBag.Status = OrderStatus.Completed;

            return View("Index", orders);
        }
    }
}
